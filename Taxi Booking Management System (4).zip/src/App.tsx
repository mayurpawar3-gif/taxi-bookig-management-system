import { useState } from "react";
import { Button } from "./components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "./components/ui/tabs";
import { User, Car, Shield } from "lucide-react";

// Context
import { AppProvider } from "./contexts/AppContext";

// Passenger Components
import { PassengerWelcome } from "./components/PassengerWelcome";
import { PassengerLogin } from "./components/PassengerLogin";
import { PassengerSignup } from "./components/PassengerSignup";
import { PassengerHome } from "./components/PassengerHome";
import { PassengerBooking } from "./components/PassengerBooking";
import { PassengerTracking } from "./components/PassengerTracking";
import { PassengerPayment } from "./components/PassengerPayment";

// Driver Components
import { DriverLogin } from "./components/DriverLogin";
import { DriverDashboard } from "./components/DriverDashboard";
import { DriverRideRequest } from "./components/DriverRideRequest";
import { DriverTrip } from "./components/DriverTrip";

// Admin Components
import { AdminDashboard } from "./components/AdminDashboard";

// Notification Bar
import { NotificationBar } from "./components/NotificationBar";

type View = "passenger" | "driver" | "admin";

type PassengerScreen = "welcome" | "login" | "signup" | "home" | "booking" | "tracking" | "payment";
type DriverScreen = "login" | "dashboard" | "request" | "trip";

export default function App() {
  const [currentView, setCurrentView] = useState<View>("passenger");
  
  // Passenger state
  const [passengerScreen, setPassengerScreen] = useState<PassengerScreen>("welcome");
  
  // Driver state
  const [driverScreen, setDriverScreen] = useState<DriverScreen>("login");
  const [driverName, setDriverName] = useState<string>("Arjun");

  const renderPassengerApp = () => {
    switch (passengerScreen) {
      case "welcome":
        return <PassengerWelcome onGetStarted={() => setPassengerScreen("login")} />;
      case "login":
        return (
          <PassengerLogin
            onBack={() => setPassengerScreen("welcome")}
            onLogin={() => setPassengerScreen("home")}
            onSignup={() => setPassengerScreen("signup")}
          />
        );
      case "signup":
        return (
          <PassengerSignup
            onBack={() => setPassengerScreen("login")}
            onSignupSuccess={() => setPassengerScreen("login")}
          />
        );
      case "home":
        return <PassengerHome onBookRide={() => setPassengerScreen("booking")} />;
      case "booking":
        return (
          <PassengerBooking
            onBack={() => setPassengerScreen("home")}
            onBook={() => setPassengerScreen("tracking")}
          />
        );
      case "tracking":
        return <PassengerTracking onComplete={() => setPassengerScreen("payment")} />;
      case "payment":
        return <PassengerPayment onComplete={() => setPassengerScreen("home")} />;
      default:
        return <PassengerWelcome onGetStarted={() => setPassengerScreen("login")} />;
    }
  };

  const renderDriverApp = () => {
    switch (driverScreen) {
      case "login":
        return <DriverLogin onLogin={(name) => {
          setDriverName(name);
          setDriverScreen("dashboard");
        }} />;
      case "dashboard":
        return (
          <>
            <DriverDashboard onNewRide={() => setDriverScreen("request")} driverName={driverName} />
            {driverScreen === "request" && (
              <DriverRideRequest
                onAccept={() => setDriverScreen("trip")}
                onReject={() => setDriverScreen("dashboard")}
              />
            )}
          </>
        );
      case "request":
        return (
          <>
            <DriverDashboard onNewRide={() => setDriverScreen("request")} driverName={driverName} />
            <DriverRideRequest
              onAccept={() => setDriverScreen("trip")}
              onReject={() => setDriverScreen("dashboard")}
            />
          </>
        );
      case "trip":
        return <DriverTrip onEndTrip={() => setDriverScreen("dashboard")} />;
      default:
        return <DriverLogin onLogin={(name) => {
          setDriverName(name);
          setDriverScreen("dashboard");
        }} />;
    }
  };

  const renderContent = () => {
    switch (currentView) {
      case "passenger":
        return renderPassengerApp();
      case "driver":
        return renderDriverApp();
      case "admin":
        return (
          <AdminDashboard 
            onNavigateToUserSignup={() => {
              setCurrentView("passenger");
              setPassengerScreen("signup");
            }}
            onNavigateToDriverSignup={() => {
              setCurrentView("driver");
              setDriverScreen("login");
              // Driver signup is part of login screen, so we just navigate there
            }}
          />
        );
      default:
        return renderPassengerApp();
    }
  };

  const getCurrentScreen = () => {
    if (currentView === "passenger") return passengerScreen;
    if (currentView === "driver") return driverScreen;
    return "dashboard";
  };

  return (
    <AppProvider>
      <div className="size-full flex flex-col bg-background">
        {/* Professional Notification Bar */}
        <NotificationBar currentView={currentView} currentScreen={getCurrentScreen()} />

        {/* View Switcher */}
        <div className="bg-white border-b shadow-sm p-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
              <Car className="w-6 h-6 text-secondary" />
            </div>
            <div>
              <h1 className="text-lg text-secondary">RideNow India</h1>
              <p className="text-xs text-muted-foreground">Mumbai Taxi Booking Management</p>
            </div>
          </div>

          <Tabs value={currentView} onValueChange={(v) => setCurrentView(v as View)}>
            <TabsList className="bg-muted">
              <TabsTrigger value="passenger" className="gap-2">
                <User className="w-4 h-4" />
                Passenger App
              </TabsTrigger>
              <TabsTrigger value="driver" className="gap-2">
                <Car className="w-4 h-4" />
                Driver App
              </TabsTrigger>
              <TabsTrigger value="admin" className="gap-2">
                <Shield className="w-4 h-4" />
                Admin Dashboard
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Reset Buttons */}
          <div className="flex gap-2">
            {currentView === "passenger" && passengerScreen !== "welcome" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPassengerScreen("welcome")}
              >
                Reset Passenger
              </Button>
            )}
            {currentView === "driver" && driverScreen !== "login" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDriverScreen("login")}
              >
                Reset Driver
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full max-w-7xl mx-auto">
          <div className="h-full bg-white shadow-lg rounded-lg overflow-hidden m-4">
            {renderContent()}
          </div>
        </div>
      </div>
      </div>
    </AppProvider>
  );
}