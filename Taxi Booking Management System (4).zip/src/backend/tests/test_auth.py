"""
Tests for authentication endpoints.
"""
import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session
from app.models import User


def test_register_user(client: TestClient):
    """Test user registration."""
    response = client.post(
        "/auth/register",
        json={
            "name": "New User",
            "email": "newuser@example.com",
            "password": "password123",
            "role": "user",
            "phone": "+919876543219",
        },
    )
    assert response.status_code == 201
    data = response.json()
    assert data["email"] == "newuser@example.com"
    assert data["name"] == "New User"
    assert data["role"] == "user"
    assert "password" not in data


def test_register_driver_with_vehicle_info(client: TestClient):
    """Test driver registration with vehicle info."""
    response = client.post(
        "/auth/register",
        json={
            "name": "New Driver",
            "email": "newdriver@example.com",
            "password": "password123",
            "role": "driver",
            "phone": "+919876543220",
            "vehicle_info": "Maruti Swift • MH 02 CD 5678",
        },
    )
    assert response.status_code == 201
    data = response.json()
    assert data["role"] == "driver"
    assert data["vehicle_info"] == "Maruti Swift • MH 02 CD 5678"


def test_register_driver_without_vehicle_info(client: TestClient):
    """Test driver registration fails without vehicle info."""
    response = client.post(
        "/auth/register",
        json={
            "name": "Bad Driver",
            "email": "baddriver@example.com",
            "password": "password123",
            "role": "driver",
            "phone": "+919876543221",
        },
    )
    assert response.status_code == 422  # Validation error


def test_register_duplicate_email(client: TestClient, test_user: User):
    """Test registration with existing email fails."""
    response = client.post(
        "/auth/register",
        json={
            "name": "Duplicate",
            "email": "test@example.com",  # Already exists
            "password": "password123",
            "role": "user",
            "phone": "+919876543222",
        },
    )
    assert response.status_code == 400
    assert "already registered" in response.json()["detail"].lower()


def test_login_success(client: TestClient, test_user: User):
    """Test successful login."""
    response = client.post(
        "/auth/login",
        json={
            "email": "test@example.com",
            "password": "testpassword",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"
    assert "user" in data
    assert data["user"]["email"] == "test@example.com"


def test_login_wrong_password(client: TestClient, test_user: User):
    """Test login with wrong password fails."""
    response = client.post(
        "/auth/login",
        json={
            "email": "test@example.com",
            "password": "wrongpassword",
        },
    )
    assert response.status_code == 401


def test_login_nonexistent_user(client: TestClient):
    """Test login with nonexistent user fails."""
    response = client.post(
        "/auth/login",
        json={
            "email": "nonexistent@example.com",
            "password": "password",
        },
    )
    assert response.status_code == 401


def test_get_current_user(client: TestClient, test_user: User, user_token: str):
    """Test getting current user info with valid token."""
    response = client.get(
        "/auth/me",
        headers={"Authorization": f"Bearer {user_token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["email"] == "test@example.com"
    assert data["name"] == "Test User"


def test_get_current_user_no_token(client: TestClient):
    """Test getting current user without token fails."""
    response = client.get("/auth/me")
    assert response.status_code == 403  # No credentials


def test_get_current_user_invalid_token(client: TestClient):
    """Test getting current user with invalid token fails."""
    response = client.get(
        "/auth/me",
        headers={"Authorization": "Bearer invalid_token"},
    )
    assert response.status_code == 401
