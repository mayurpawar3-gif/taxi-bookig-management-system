"""
Tests for ride management endpoints.
"""
import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session
from app.models import User, Ride


def test_create_ride(client: TestClient, test_user: User, user_token: str):
    """Test creating a ride request."""
    response = client.post(
        "/rides",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "origin": "Marine Drive, Mumbai",
            "destination": "Andheri Airport, Mumbai",
            "origin_lat": 18.9432,
            "origin_lon": 72.8236,
            "destination_lat": 19.0896,
            "destination_lon": 72.8656,
            "vehicle_type": "sedan",
        },
    )
    assert response.status_code == 201
    data = response.json()
    assert data["origin"] == "Marine Drive, Mumbai"
    assert data["destination"] == "Andheri Airport, Mumbai"
    assert data["status"] == "requested"
    assert data["user_id"] == test_user.id


def test_create_ride_no_auth(client: TestClient):
    """Test creating ride without authentication fails."""
    response = client.post(
        "/rides",
        json={
            "origin": "Location A",
            "destination": "Location B",
            "vehicle_type": "sedan",
        },
    )
    assert response.status_code == 403


def test_cannot_create_multiple_active_rides(
    client: TestClient,
    session: Session,
    test_user: User,
    user_token: str,
):
    """Test user cannot create multiple active rides."""
    # Create first ride
    ride1 = client.post(
        "/rides",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "origin": "Location A",
            "destination": "Location B",
            "vehicle_type": "sedan",
        },
    )
    assert ride1.status_code == 201
    
    # Try to create second ride (should fail)
    ride2 = client.post(
        "/rides",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "origin": "Location C",
            "destination": "Location D",
            "vehicle_type": "mini",
        },
    )
    assert ride2.status_code == 400
    assert "active ride" in ride2.json()["detail"].lower()


def test_get_available_rides(
    client: TestClient,
    session: Session,
    test_user: User,
    test_driver: User,
    user_token: str,
    driver_token: str,
):
    """Test drivers can see available rides."""
    # User creates a ride
    client.post(
        "/rides",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "origin": "Location A",
            "destination": "Location B",
            "vehicle_type": "sedan",
        },
    )
    
    # Driver fetches available rides
    response = client.get(
        "/rides/available",
        headers={"Authorization": f"Bearer {driver_token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["status"] == "requested"
    assert "user_name" in data[0]


def test_driver_accept_ride(
    client: TestClient,
    session: Session,
    test_user: User,
    test_driver: User,
    user_token: str,
    driver_token: str,
):
    """Test driver can accept a ride."""
    # User creates ride
    ride_response = client.post(
        "/rides",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "origin": "Location A",
            "destination": "Location B",
            "vehicle_type": "sedan",
        },
    )
    ride_id = ride_response.json()["id"]
    
    # Driver accepts ride
    response = client.post(
        f"/rides/{ride_id}/accept",
        headers={"Authorization": f"Bearer {driver_token}"},
        json={"estimated_time": "5 min"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "accepted"
    assert data["driver_id"] == test_driver.id


def test_complete_ride_flow(
    client: TestClient,
    session: Session,
    test_user: User,
    test_driver: User,
    user_token: str,
    driver_token: str,
):
    """Test complete ride flow from creation to completion."""
    # 1. User creates ride
    ride_response = client.post(
        "/rides",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "origin": "Location A",
            "destination": "Location B",
            "vehicle_type": "sedan",
        },
    )
    assert ride_response.status_code == 201
    ride_id = ride_response.json()["id"]
    
    # 2. Driver accepts ride
    accept_response = client.post(
        f"/rides/{ride_id}/accept",
        headers={"Authorization": f"Bearer {driver_token}"},
        json={"estimated_time": "5 min"},
    )
    assert accept_response.status_code == 200
    assert accept_response.json()["status"] == "accepted"
    
    # 3. Driver starts ride
    start_response = client.post(
        f"/rides/{ride_id}/start",
        headers={"Authorization": f"Bearer {driver_token}"},
    )
    assert start_response.status_code == 200
    assert start_response.json()["status"] == "in_progress"
    
    # 4. Driver completes ride
    complete_response = client.post(
        f"/rides/{ride_id}/complete",
        headers={"Authorization": f"Bearer {driver_token}"},
        json={
            "fare": 250.0,
            "distance_km": 12.5,
        },
    )
    assert complete_response.status_code == 200
    data = complete_response.json()
    assert data["status"] == "completed"
    assert data["fare"] == 250.0
    assert data["distance_km"] == 12.5


def test_user_can_cancel_own_ride(
    client: TestClient,
    test_user: User,
    user_token: str,
):
    """Test user can cancel their own ride."""
    # Create ride
    ride_response = client.post(
        "/rides",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "origin": "Location A",
            "destination": "Location B",
            "vehicle_type": "sedan",
        },
    )
    ride_id = ride_response.json()["id"]
    
    # Cancel ride
    response = client.post(
        f"/rides/{ride_id}/cancel",
        headers={"Authorization": f"Bearer {user_token}"},
    )
    assert response.status_code == 200
    assert response.json()["status"] == "cancelled"


def test_cannot_accept_already_accepted_ride(
    client: TestClient,
    session: Session,
    test_user: User,
    test_driver: User,
    driver_token: str,
):
    """Test cannot accept a ride that's already accepted."""
    # Create another driver
    from app.models import UserRole
    from app.auth import hash_password
    
    driver2 = User(
        name="Driver 2",
        email="driver2@example.com",
        password_hash=hash_password("testpassword"),
        role=UserRole.DRIVER,
        phone="+919876543299",
        vehicle_info="Test Vehicle 2",
        is_active=True,
        is_available=True,
    )
    session.add(driver2)
    session.commit()
    
    # Get token for driver2
    login_response = client.post(
        "/auth/login",
        json={"email": "driver2@example.com", "password": "testpassword"},
    )
    driver2_token = login_response.json()["access_token"]
    
    # Create user and ride
    from app import crud
    ride_data = {
        "origin": "Location A",
        "destination": "Location B",
        "vehicle_type": "sedan",
    }
    from app.schemas import RideCreate
    ride = crud.create_ride(session, test_user.id, RideCreate(**ride_data))
    
    # First driver accepts
    response1 = client.post(
        f"/rides/{ride.id}/accept",
        headers={"Authorization": f"Bearer {driver_token}"},
        json={"estimated_time": "5 min"},
    )
    assert response1.status_code == 200
    
    # Second driver tries to accept (should fail)
    response2 = client.post(
        f"/rides/{ride.id}/accept",
        headers={"Authorization": f"Bearer {driver2_token}"},
        json={"estimated_time": "3 min"},
    )
    assert response2.status_code == 400
