"""
Pytest configuration and fixtures.
"""
import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, create_engine, SQLModel
from sqlalchemy.pool import StaticPool

from app.main import app
from app.database import get_session
from app.models import User, UserRole
from app.auth import hash_password


# Create in-memory SQLite database for testing
@pytest.fixture(name="session")
def session_fixture():
    """Create a test database session."""
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    SQLModel.metadata.create_all(engine)
    
    with Session(engine) as session:
        yield session


@pytest.fixture(name="client")
def client_fixture(session: Session):
    """Create a test client with overridden database session."""
    def get_session_override():
        return session
    
    app.dependency_overrides[get_session] = get_session_override
    client = TestClient(app)
    yield client
    app.dependency_overrides.clear()


@pytest.fixture(name="test_user")
def test_user_fixture(session: Session):
    """Create a test user."""
    user = User(
        name="Test User",
        email="test@example.com",
        password_hash=hash_password("testpassword"),
        role=UserRole.USER,
        phone="+919876543210",
        is_active=True,
    )
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


@pytest.fixture(name="test_driver")
def test_driver_fixture(session: Session):
    """Create a test driver."""
    driver = User(
        name="Test Driver",
        email="driver@example.com",
        password_hash=hash_password("testpassword"),
        role=UserRole.DRIVER,
        phone="+919876543211",
        vehicle_info="Test Vehicle • MH 01 AB 1234",
        is_active=True,
        is_available=True,
        last_latitude=19.0760,
        last_longitude=72.8777,
    )
    session.add(driver)
    session.commit()
    session.refresh(driver)
    return driver


@pytest.fixture(name="test_admin")
def test_admin_fixture(session: Session):
    """Create a test admin."""
    admin = User(
        name="Test Admin",
        email="admin@example.com",
        password_hash=hash_password("testpassword"),
        role=UserRole.ADMIN,
        phone="+919876543212",
        is_active=True,
    )
    session.add(admin)
    session.commit()
    session.refresh(admin)
    return admin


@pytest.fixture(name="user_token")
def user_token_fixture(client: TestClient, test_user: User):
    """Get authentication token for test user."""
    response = client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "testpassword"},
    )
    return response.json()["access_token"]


@pytest.fixture(name="driver_token")
def driver_token_fixture(client: TestClient, test_driver: User):
    """Get authentication token for test driver."""
    response = client.post(
        "/auth/login",
        json={"email": "driver@example.com", "password": "testpassword"},
    )
    return response.json()["access_token"]


@pytest.fixture(name="admin_token")
def admin_token_fixture(client: TestClient, test_admin: User):
    """Get authentication token for test admin."""
    response = client.post(
        "/auth/login",
        json={"email": "admin@example.com", "password": "testpassword"},
    )
    return response.json()["access_token"]
