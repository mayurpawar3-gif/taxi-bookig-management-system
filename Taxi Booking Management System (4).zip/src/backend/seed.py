"""
Database seeding script to populate initial data.
"""
from sqlmodel import Session
from app.database import engine
from app.models import User, UserRole
from app.auth import hash_password
from app.config import settings
import structlog

logger = structlog.get_logger()


def seed_database():
    """Seed the database with initial users."""
    with Session(engine) as session:
        # Check if data already exists
        existing_users = session.query(User).count()
        if existing_users > 0:
            logger.info(f"Database already contains {existing_users} users. Skipping seed.")
            return
        
        logger.info("Seeding database with initial data...")
        
        # Create Admin
        admin = User(
            name="Admin User",
            email="admin123@gmail.com",
            password_hash=hash_password("password"),
            role=UserRole.ADMIN,
            phone="+919876543210",
            is_active=True,
            is_available=False,
        )
        session.add(admin)
        logger.info("Created admin: admin123@gmail.com / password")
        
        # Create Drivers
        drivers = [
            User(
                name="Rajesh Kumar",
                email="driver123@gmail.com",
                password_hash=hash_password("password"),
                role=UserRole.DRIVER,
                phone="+919876543211",
                vehicle_info="Maruti Ertiga • MH 02 BX 5678",
                is_active=True,
                is_available=True,
                last_latitude=19.0760,  # Mumbai
                last_longitude=72.8777,
            ),
            User(
                name="Amit Verma",
                email="driver124@gmail.com",
                password_hash=hash_password("password"),
                role=UserRole.DRIVER,
                phone="+919876543212",
                vehicle_info="Hyundai i20 • MH 01 CK 1234",
                is_active=True,
                is_available=True,
                last_latitude=19.0896,
                last_longitude=72.8656,
            ),
        ]
        
        for driver in drivers:
            session.add(driver)
            logger.info(f"Created driver: {driver.email} / password")
        
        # Create Users (Passengers)
        users = [
            User(
                name="Arjun Sharma",
                email="user123@gmail.com",
                password_hash=hash_password("password"),
                role=UserRole.USER,
                phone="+919876543213",
                is_active=True,
                is_available=False,
            ),
            User(
                name="Priya Patel",
                email="user124@gmail.com",
                password_hash=hash_password("password"),
                role=UserRole.USER,
                phone="+919876543214",
                is_active=True,
                is_available=False,
            ),
            User(
                name="Rohan Mehta",
                email="user125@gmail.com",
                password_hash=hash_password("password"),
                role=UserRole.USER,
                phone="+919876543215",
                is_active=True,
                is_available=False,
            ),
        ]
        
        for user in users:
            session.add(user)
            logger.info(f"Created user: {user.email} / password")
        
        # Commit all changes
        session.commit()
        
        logger.info("✅ Database seeded successfully!")
        logger.info("\n📝 Login Credentials:")
        logger.info("  Admin:  admin123@gmail.com / password")
        logger.info("  Driver: driver123@gmail.com / password")
        logger.info("  Driver: driver124@gmail.com / password")
        logger.info("  User:   user123@gmail.com / password")
        logger.info("  User:   user124@gmail.com / password")
        logger.info("  User:   user125@gmail.com / password")


if __name__ == "__main__":
    seed_database()
