# RideNow India - Taxi Management System Backend

A production-ready FastAPI backend for a comprehensive taxi booking and management system with real-time features.

## 🚀 Features

- **Authentication & Authorization**: JWT-based with role-based access control (Admin, Driver, User)
- **Ride Management**: Complete ride lifecycle from booking to completion
- **Real-time Communication**: WebSocket support for chat and live updates
- **Location Services**: Haversine-based nearby driver search
- **Revenue Tracking**: Automatic commission calculation and reporting
- **Admin Dashboard**: Comprehensive statistics and management tools
- **Secure**: Password hashing with pbkdf2_sha256, input validation, rate limiting
- **Production-Ready**: Docker support, structured logging, health checks, CI/CD

## 📋 Prerequisites

- Python 3.10+
- PostgreSQL 15+ (or SQLite for local dev)
- Docker & Docker Compose (optional)

## 🏗️ Project Structure

```
backend/
├── app/
│   ├── main.py              # FastAPI application entry point
│   ├── config.py            # Configuration management
│   ├── database.py          # Database setup and session management
│   ├── models.py            # SQLModel database models
│   ├── schemas.py           # Pydantic request/response schemas
│   ├── crud.py              # Database CRUD operations
│   ├── auth.py              # Authentication utilities
│   ├── deps.py              # FastAPI dependencies
│   └── routers/             # API route handlers
│       ├── auth.py
│       ├── users.py
│       ├── drivers.py
│       ├── rides.py
│       ├── admin.py
│       └── chat.py
├── migrations/              # Alembic database migrations
├── tests/                   # Pytest test suite
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── seed.py                  # Database seeding script
└── README.md
```

## 🚦 Quick Start

### Option 1: Docker Compose (Recommended)

1. **Clone and setup**:
   ```bash
   cd backend
   cp .env.example .env
   ```

2. **Start services**:
   ```bash
   docker-compose up --build
   ```

3. **Seed database** (in another terminal):
   ```bash
   docker-compose exec backend python seed.py
   ```

4. **Access API**:
   - API: http://localhost:8000
   - Docs: http://localhost:8000/docs
   - Health: http://localhost:8000/healthz

### Option 2: Local Development

1. **Create virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Setup environment**:
   ```bash
   cp .env.example .env
   # Edit .env with your settings
   ```

4. **Run database migrations** (if using PostgreSQL):
   ```bash
   alembic upgrade head
   ```

5. **Seed database**:
   ```bash
   python seed.py
   ```

6. **Run server**:
   ```bash
   uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   ```

## 🔐 Default Login Credentials

After seeding the database, use these credentials:

| Role   | Email                 | Password |
|--------|-----------------------|----------|
| Admin  | admin123@gmail.com    | password |
| Driver | driver123@gmail.com   | password |
| Driver | driver124@gmail.com   | password |
| User   | user123@gmail.com     | password |
| User   | user124@gmail.com     | password |
| User   | user125@gmail.com     | password |

## 📡 API Endpoints

### Authentication

```bash
# Register a new user
POST /auth/register
Body: {
  "name": "John Doe",
  "email": "john@example.com",
  "password": "secure123",
  "role": "user",
  "phone": "+919876543210"
}

# Login
POST /auth/login
Body: {
  "email": "user123@gmail.com",
  "password": "password"
}

# Get current user
GET /auth/me
Headers: Authorization: Bearer <token>
```

### Rides

```bash
# Create a ride
POST /rides
Headers: Authorization: Bearer <user_token>
Body: {
  "origin": "Marine Drive, Mumbai",
  "destination": "Andheri Airport, Mumbai",
  "vehicle_type": "sedan"
}

# List available rides (for drivers)
GET /rides/available
Headers: Authorization: Bearer <driver_token>

# Accept a ride
POST /rides/{ride_id}/accept
Headers: Authorization: Bearer <driver_token>
Body: {"estimated_time": "5 min"}

# Start a ride
POST /rides/{ride_id}/start
Headers: Authorization: Bearer <driver_token>

# Complete a ride
POST /rides/{ride_id}/complete
Headers: Authorization: Bearer <driver_token>
Body: {
  "fare": 250.0,
  "distance_km": 12.5
}
```

### Drivers

```bash
# Find nearby drivers
GET /drivers/nearby?latitude=19.0760&longitude=72.8777&radius=5
Headers: Authorization: Bearer <token>

# Update driver location
POST /drivers/location
Headers: Authorization: Bearer <driver_token>
Body: {
  "latitude": 19.0760,
  "longitude": 72.8777
}

# Toggle availability
PATCH /drivers/availability?is_available=true
Headers: Authorization: Bearer <driver_token>
```

### Admin

```bash
# Get system statistics
GET /admin/stats
Headers: Authorization: Bearer <admin_token>

# Get revenue records
GET /admin/revenue?skip=0&limit=100
Headers: Authorization: Bearer <admin_token>
```

### Chat

```bash
# Send a message
POST /chat/{ride_id}
Headers: Authorization: Bearer <token>
Body: {"message": "Hello!"}

# Get messages for a ride
GET /chat/{ride_id}
Headers: Authorization: Bearer <token>

# WebSocket for real-time chat
WS /chat/ws/{ride_id}?token=<your_token>
```

## 🧪 Testing

Run the test suite:

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=app --cov-report=html

# Run specific test file
pytest tests/test_auth.py

# Run with verbose output
pytest -v
```

## 🔧 Configuration

Environment variables (see `.env.example`):

| Variable | Description | Default |
|----------|-------------|---------|
| DATABASE_URL | Database connection string | sqlite:///./ridenow.db |
| SECRET_KEY | JWT signing key | (change in production) |
| ACCESS_TOKEN_EXPIRE_MINUTES | Token expiration time | 60 |
| ALLOWED_ORIGINS | CORS allowed origins | http://localhost:3000,... |
| DEBUG | Debug mode | True |
| ENVIRONMENT | Environment name | development |

## 📊 Database Schema

### Users Table
- id, name, email, password_hash, role, phone
- vehicle_info (for drivers)
- is_active, is_available
- last_latitude, last_longitude (for drivers)
- created_at, updated_at

### Rides Table
- id, user_id, driver_id
- origin, destination, coordinates
- status, fare, distance_km, estimated_time
- vehicle_type, metadata (JSON)
- created_at, updated_at, accepted_at, started_at, completed_at

### Chat Table
- id, ride_id, sender_id, message
- created_at

### Revenue Table
- id, ride_id, amount
- driver_commission, platform_commission
- created_at

### Locations Table (optional)
- id, ride_id, driver_id
- lat, lon, recorded_at

## 🔄 Database Migrations

Using Alembic:

```bash
# Create a new migration
alembic revision --autogenerate -m "Description"

# Apply migrations
alembic upgrade head

# Rollback last migration
alembic downgrade -1

# Show current version
alembic current
```

## 🐳 Docker Commands

```bash
# Build and start
docker-compose up --build

# Start in background
docker-compose up -d

# View logs
docker-compose logs -f backend

# Stop services
docker-compose down

# Remove volumes
docker-compose down -v

# Execute commands in container
docker-compose exec backend python seed.py
docker-compose exec backend alembic upgrade head
docker-compose exec postgres psql -U postgres -d ridenow
```

## 🛡️ Security Features

- **Password Hashing**: pbkdf2_sha256 with 200,000 rounds
- **JWT Tokens**: Short-lived tokens with secure signing
- **Role-Based Access**: Admin, Driver, User roles with route protection
- **Input Validation**: Pydantic schemas for all requests
- **SQL Injection Protection**: SQLModel/SQLAlchemy parameterized queries
- **CORS**: Configurable allowed origins
- **Rate Limiting**: Ready for Redis-based limiting (add middleware)

## 📈 Monitoring & Logging

- **Structured Logging**: JSON format with structlog
- **Health Checks**: `/healthz` endpoint
- **Request Logging**: Automatic timing and error logging
- **Docker Health**: Built-in container health checks

## 🔌 WebSocket Example

```javascript
// Connect to WebSocket
const ws = new WebSocket('ws://localhost:8000/chat/ws/1?token=YOUR_JWT_TOKEN');

// Send message
ws.send(JSON.stringify({
  type: 'chat',
  message: 'Hello!'
}));

// Receive messages
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log(data);
};
```

## 🚀 Deployment

### Production Checklist

- [ ] Change `SECRET_KEY` to a strong random value
- [ ] Set `DEBUG=False`
- [ ] Configure PostgreSQL with SSL
- [ ] Set up proper CORS origins
- [ ] Enable HTTPS/TLS
- [ ] Configure rate limiting
- [ ] Set up monitoring (Prometheus/Grafana)
- [ ] Configure backup strategy
- [ ] Set up CI/CD pipeline
- [ ] Review security headers

### Docker Production Build

```bash
# Build production image
docker build -t ridenow-api:latest .

# Run production container
docker run -d \
  -p 8000:8000 \
  -e DATABASE_URL=postgresql://user:pass@host:5432/db \
  -e SECRET_KEY=your-production-secret-key \
  -e DEBUG=False \
  ridenow-api:latest
```

## 🧹 Code Quality

```bash
# Format code
black app tests

# Sort imports
isort app tests

# Lint code
flake8 app tests

# Type checking (optional)
mypy app
```

## 📝 Sample cURL Commands

### Complete Ride Flow

```bash
# 1. Register a user
curl -X POST http://localhost:8000/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Arjun Kumar",
    "email": "arjun@example.com",
    "password": "secure123",
    "role": "user",
    "phone": "+919876543210"
  }'

# 2. Login to get token
curl -X POST http://localhost:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "arjun@example.com",
    "password": "secure123"
  }'

# Save the access_token from response

# 3. Create a ride
curl -X POST http://localhost:8000/rides \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "origin": "Marine Drive, Mumbai",
    "destination": "Andheri Airport, Mumbai",
    "vehicle_type": "sedan"
  }'

# 4. Driver login
curl -X POST http://localhost:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "driver123@gmail.com",
    "password": "password"
  }'

# 5. Get available rides (driver)
curl -X GET http://localhost:8000/rides/available \
  -H "Authorization: Bearer DRIVER_TOKEN"

# 6. Accept ride
curl -X POST http://localhost:8000/rides/RIDE_ID/accept \
  -H "Authorization: Bearer DRIVER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"estimated_time": "5 min"}'

# 7. Start ride
curl -X POST http://localhost:8000/rides/RIDE_ID/start \
  -H "Authorization: Bearer DRIVER_TOKEN"

# 8. Complete ride
curl -X POST http://localhost:8000/rides/RIDE_ID/complete \
  -H "Authorization: Bearer DRIVER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "fare": 250.0,
    "distance_km": 12.5
  }'

# 9. Get admin stats
curl -X GET http://localhost:8000/admin/stats \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

## 📚 Additional Resources

- **FastAPI Docs**: https://fastapi.tiangolo.com
- **SQLModel Docs**: https://sqlmodel.tiangolo.com
- **Alembic Docs**: https://alembic.sqlalchemy.org
- **Pydantic Docs**: https://docs.pydantic.dev

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests and linting
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For issues and questions:
- Check the API documentation at `/docs`
- Review the logs for error details
- Open an issue in the repository

---

**Made with ❤️ for RideNow India**
