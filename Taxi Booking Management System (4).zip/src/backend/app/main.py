"""
FastAPI main application entry point.
"""
from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
import time
import structlog
from contextlib import asynccontextmanager

from app.config import settings
from app.database import create_db_and_tables
from app.routers import auth, users, drivers, rides, admin, chat

# Configure structured logging
structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.stdlib.add_log_level,
        structlog.processors.JSONRenderer() if settings.LOG_FORMAT == "json"
        else structlog.dev.ConsoleRenderer(),
    ],
)

logger = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for startup and shutdown events.
    """
    # Startup
    logger.info("Starting RideNow India Taxi Management API")
    logger.info(f"Environment: {settings.ENVIRONMENT}")
    logger.info(f"Database: {'PostgreSQL' if settings.is_postgres else 'SQLite'}")
    
    # Create database tables
    create_db_and_tables()
    logger.info("Database tables created")
    
    yield
    
    # Shutdown
    logger.info("Shutting down RideNow India Taxi Management API")


# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="""
    ## RideNow India - Taxi Management System API
    
    A comprehensive backend for taxi booking and management with real-time features.
    
    ### Features
    * 🔐 JWT-based authentication
    * 👥 User, Driver, and Admin roles
    * 🚗 Real-time ride booking and tracking
    * 💬 WebSocket-based chat
    * 💰 Revenue tracking and reporting
    * 📍 Location-based driver search
    * 📊 Admin statistics dashboard
    
    ### Authentication
    Most endpoints require a JWT token in the Authorization header:
    ```
    Authorization: Bearer <your_token>
    ```
    
    Get a token by calling `/auth/login` with valid credentials.
    
    ### Sample Accounts
    - **Admin**: admin123@gmail.com / password
    - **Driver**: driver123@gmail.com / password
    - **User**: user123@gmail.com / password
    """,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all HTTP requests with timing."""
    start_time = time.time()
    
    # Log request
    logger.info(
        "http_request_started",
        method=request.method,
        path=request.url.path,
        client=request.client.host if request.client else None,
    )
    
    # Process request
    try:
        response = await call_next(request)
        process_time = time.time() - start_time
        
        # Log response
        logger.info(
            "http_request_completed",
            method=request.method,
            path=request.url.path,
            status_code=response.status_code,
            process_time=f"{process_time:.3f}s",
        )
        
        # Add timing header
        response.headers["X-Process-Time"] = str(process_time)
        return response
        
    except Exception as e:
        process_time = time.time() - start_time
        logger.error(
            "http_request_failed",
            method=request.method,
            path=request.url.path,
            error=str(e),
            process_time=f"{process_time:.3f}s",
        )
        raise


# Exception handlers
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler."""
    logger.error(
        "unhandled_exception",
        method=request.method,
        path=request.url.path,
        error=str(exc),
        error_type=type(exc).__name__,
    )
    
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "detail": "Internal server error",
            "error": str(exc) if settings.DEBUG else "An error occurred",
        },
    )


# Health check endpoint
@app.get("/healthz", tags=["Health"])
async def health_check():
    """
    Health check endpoint.
    
    Returns server status and version info.
    """
    return {
        "status": "healthy",
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
    }


@app.get("/", tags=["Root"])
async def root():
    """
    Root endpoint with API information.
    """
    return {
        "message": "Welcome to RideNow India Taxi Management API",
        "version": settings.APP_VERSION,
        "docs": "/docs",
        "health": "/healthz",
    }


# Include routers
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(drivers.router)
app.include_router(rides.router)
app.include_router(admin.router)
app.include_router(chat.router)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower(),
    )
