"""
CRUD operations for database models.
"""
from typing import Optional, List
from datetime import datetime, timedelta
from sqlmodel import Session, select, and_, or_, func
from sqlalchemy import desc
from app.models import User, Ride, Chat, Revenue, Location, UserRole, RideStatus
from app.schemas import UserRegister, RideCreate, ChatCreate, DriverLocation
from app.auth import hash_password
import math


# ========== User CRUD ==========

def create_user(session: Session, user_data: UserRegister) -> User:
    """Create a new user."""
    password_hash = hash_password(user_data.password)
    
    user = User(
        name=user_data.name,
        email=user_data.email,
        password_hash=password_hash,
        role=user_data.role,
        phone=user_data.phone,
        vehicle_info=user_data.vehicle_info,
        is_available=(user_data.role == UserRole.DRIVER),  # Drivers start as available
    )
    
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


def get_user_by_email(session: Session, email: str) -> Optional[User]:
    """Get user by email."""
    statement = select(User).where(User.email == email)
    return session.exec(statement).first()


def get_user_by_id(session: Session, user_id: int) -> Optional[User]:
    """Get user by ID."""
    return session.get(User, user_id)


def update_user(session: Session, user: User, **kwargs) -> User:
    """Update user fields."""
    for key, value in kwargs.items():
        if value is not None and hasattr(user, key):
            setattr(user, key, value)
    
    user.updated_at = datetime.utcnow()
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


def update_driver_location(
    session: Session,
    driver: User,
    location: DriverLocation
) -> User:
    """Update driver's last known location."""
    driver.last_latitude = location.latitude
    driver.last_longitude = location.longitude
    driver.updated_at = datetime.utcnow()
    
    session.add(driver)
    session.commit()
    session.refresh(driver)
    return driver


# ========== Ride CRUD ==========

def create_ride(session: Session, user_id: int, ride_data: RideCreate) -> Ride:
    """Create a new ride request."""
    # Calculate estimated fare (simple formula)
    base_fare = 50.0
    per_km_rate = 15.0
    estimated_distance = ride_data.metadata.get("distance_km", 10.0) if ride_data.metadata else 10.0
    estimated_fare = base_fare + (estimated_distance * per_km_rate)
    
    ride = Ride(
        user_id=user_id,
        origin=ride_data.origin,
        destination=ride_data.destination,
        origin_lat=ride_data.origin_lat,
        origin_lon=ride_data.origin_lon,
        destination_lat=ride_data.destination_lat,
        destination_lon=ride_data.destination_lon,
        vehicle_type=ride_data.vehicle_type,
        status=RideStatus.REQUESTED,
        fare=estimated_fare,
        metadata=ride_data.metadata or {},
    )
    
    session.add(ride)
    session.commit()
    session.refresh(ride)
    return ride


def get_ride_by_id(session: Session, ride_id: int) -> Optional[Ride]:
    """Get ride by ID."""
    return session.get(Ride, ride_id)


def get_user_rides(
    session: Session,
    user_id: int,
    status: Optional[RideStatus] = None,
    skip: int = 0,
    limit: int = 20
) -> List[Ride]:
    """Get rides for a user with optional status filter."""
    statement = select(Ride).where(Ride.user_id == user_id)
    
    if status:
        statement = statement.where(Ride.status == status)
    
    statement = statement.order_by(desc(Ride.created_at)).offset(skip).limit(limit)
    return list(session.exec(statement).all())


def get_driver_rides(
    session: Session,
    driver_id: int,
    status: Optional[RideStatus] = None,
    skip: int = 0,
    limit: int = 20
) -> List[Ride]:
    """Get rides for a driver with optional status filter."""
    statement = select(Ride).where(Ride.driver_id == driver_id)
    
    if status:
        statement = statement.where(Ride.status == status)
    
    statement = statement.order_by(desc(Ride.created_at)).offset(skip).limit(limit)
    return list(session.exec(statement).all())


def check_user_has_active_ride(session: Session, user_id: int) -> bool:
    """Check if user has any active ride (requested or in_progress)."""
    statement = select(Ride).where(
        and_(
            Ride.user_id == user_id,
            or_(
                Ride.status == RideStatus.REQUESTED,
                Ride.status == RideStatus.ACCEPTED,
                Ride.status == RideStatus.IN_PROGRESS
            )
        )
    )
    return session.exec(statement).first() is not None


def accept_ride(
    session: Session,
    ride: Ride,
    driver_id: int,
    estimated_time: str = "5 min"
) -> Ride:
    """
    Driver accepts a ride.
    Uses SELECT FOR UPDATE to prevent race conditions.
    """
    # Lock the ride row for update
    statement = select(Ride).where(Ride.id == ride.id).with_for_update()
    locked_ride = session.exec(statement).first()
    
    if not locked_ride:
        raise ValueError("Ride not found")
    
    if locked_ride.status != RideStatus.REQUESTED:
        raise ValueError("Ride is not available for acceptance")
    
    locked_ride.driver_id = driver_id
    locked_ride.status = RideStatus.ACCEPTED
    locked_ride.accepted_at = datetime.utcnow()
    locked_ride.estimated_time = estimated_time
    locked_ride.updated_at = datetime.utcnow()
    
    session.add(locked_ride)
    session.commit()
    session.refresh(locked_ride)
    return locked_ride


def start_ride(session: Session, ride: Ride) -> Ride:
    """Driver starts the ride."""
    ride.status = RideStatus.IN_PROGRESS
    ride.started_at = datetime.utcnow()
    ride.updated_at = datetime.utcnow()
    
    session.add(ride)
    session.commit()
    session.refresh(ride)
    return ride


def complete_ride(
    session: Session,
    ride: Ride,
    fare: float,
    distance_km: float
) -> Ride:
    """Complete a ride and create revenue record."""
    ride.status = RideStatus.COMPLETED
    ride.fare = fare
    ride.distance_km = distance_km
    ride.completed_at = datetime.utcnow()
    ride.updated_at = datetime.utcnow()
    
    session.add(ride)
    
    # Create revenue record (80% to driver, 20% to platform)
    driver_commission = fare * 0.8
    platform_commission = fare * 0.2
    
    revenue = Revenue(
        ride_id=ride.id,
        amount=fare,
        driver_commission=driver_commission,
        platform_commission=platform_commission,
    )
    session.add(revenue)
    
    session.commit()
    session.refresh(ride)
    return ride


def cancel_ride(session: Session, ride: Ride) -> Ride:
    """Cancel a ride."""
    ride.status = RideStatus.CANCELLED
    ride.updated_at = datetime.utcnow()
    
    session.add(ride)
    session.commit()
    session.refresh(ride)
    return ride


def get_available_rides(session: Session, limit: int = 20) -> List[Ride]:
    """Get all requested rides (for drivers to see available rides)."""
    statement = (
        select(Ride)
        .where(Ride.status == RideStatus.REQUESTED)
        .order_by(Ride.created_at)
        .limit(limit)
    )
    return list(session.exec(statement).all())


# ========== Driver Search ==========

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate the great circle distance between two points on the earth.
    Returns distance in kilometers.
    """
    # Convert to radians
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    
    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    # Radius of earth in kilometers
    r = 6371
    
    return c * r


def get_nearby_drivers(
    session: Session,
    latitude: float,
    longitude: float,
    radius_km: float = 5.0
) -> List[User]:
    """
    Get available drivers near a location.
    Uses simple Haversine distance calculation.
    """
    # Get all available drivers with location
    statement = select(User).where(
        and_(
            User.role == UserRole.DRIVER,
            User.is_available == True,
            User.last_latitude.isnot(None),
            User.last_longitude.isnot(None)
        )
    )
    
    all_drivers = list(session.exec(statement).all())
    
    # Filter by distance
    nearby = []
    for driver in all_drivers:
        distance = haversine_distance(
            latitude,
            longitude,
            driver.last_latitude,
            driver.last_longitude
        )
        if distance <= radius_km:
            # Add distance as attribute for sorting
            driver.distance_km = distance
            nearby.append(driver)
    
    # Sort by distance
    nearby.sort(key=lambda d: d.distance_km)
    return nearby


# ========== Chat CRUD ==========

def create_chat_message(
    session: Session,
    ride_id: int,
    sender_id: int,
    message_data: ChatCreate
) -> Chat:
    """Create a new chat message."""
    chat = Chat(
        ride_id=ride_id,
        sender_id=sender_id,
        message=message_data.message,
    )
    
    session.add(chat)
    session.commit()
    session.refresh(chat)
    return chat


def get_ride_chat_messages(
    session: Session,
    ride_id: int,
    limit: int = 100
) -> List[Chat]:
    """Get chat messages for a ride."""
    statement = (
        select(Chat)
        .where(Chat.ride_id == ride_id)
        .order_by(Chat.created_at)
        .limit(limit)
    )
    return list(session.exec(statement).all())


# ========== Admin/Stats CRUD ==========

def get_total_users(session: Session, role: Optional[UserRole] = None) -> int:
    """Get total count of users, optionally filtered by role."""
    statement = select(func.count(User.id))
    if role:
        statement = statement.where(User.role == role)
    return session.exec(statement).one()


def get_total_rides(session: Session, status: Optional[RideStatus] = None) -> int:
    """Get total count of rides, optionally filtered by status."""
    statement = select(func.count(Ride.id))
    if status:
        statement = statement.where(Ride.status == status)
    return session.exec(statement).one()


def get_total_revenue(session: Session) -> float:
    """Get total platform revenue."""
    statement = select(func.sum(Revenue.amount))
    result = session.exec(statement).one()
    return result if result else 0.0


def get_revenue_today(session: Session) -> float:
    """Get today's revenue."""
    today = datetime.utcnow().date()
    statement = select(func.sum(Revenue.amount)).where(
        func.date(Revenue.created_at) == today
    )
    result = session.exec(statement).one()
    return result if result else 0.0


def get_completed_rides_today(session: Session) -> int:
    """Get count of completed rides today."""
    today = datetime.utcnow().date()
    statement = select(func.count(Ride.id)).where(
        and_(
            Ride.status == RideStatus.COMPLETED,
            func.date(Ride.completed_at) == today
        )
    )
    return session.exec(statement).one()


# ========== Location Tracking ==========

def create_location_update(
    session: Session,
    ride_id: int,
    driver_id: int,
    latitude: float,
    longitude: float
) -> Location:
    """Create a location tracking record."""
    location = Location(
        ride_id=ride_id,
        driver_id=driver_id,
        lat=latitude,
        lon=longitude,
    )
    
    session.add(location)
    session.commit()
    session.refresh(location)
    return location


def get_ride_location_history(
    session: Session,
    ride_id: int,
    limit: int = 100
) -> List[Location]:
    """Get location history for a ride."""
    statement = (
        select(Location)
        .where(Location.ride_id == ride_id)
        .order_by(Location.recorded_at)
        .limit(limit)
    )
    return list(session.exec(statement).all())
