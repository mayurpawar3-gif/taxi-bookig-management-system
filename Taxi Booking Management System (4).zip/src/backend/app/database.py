"""
Database setup and session management.
"""
from sqlmodel import Session, create_engine, SQLModel
from sqlalchemy.pool import StaticPool
from typing import Generator
from app.config import settings

# Create engine based on database type
if settings.is_sqlite:
    # SQLite configuration for local dev
    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=settings.DEBUG,
    )
else:
    # PostgreSQL configuration
    engine = create_engine(
        settings.DATABASE_URL,
        echo=settings.DEBUG,
        pool_pre_ping=True,
        pool_size=10,
        max_overflow=20,
    )


def create_db_and_tables():
    """Create all database tables."""
    SQLModel.metadata.create_all(engine)


def get_session() -> Generator[Session, None, None]:
    """
    Dependency to get database session.
    Yields a session and ensures it's closed after use.
    """
    with Session(engine) as session:
        yield session
