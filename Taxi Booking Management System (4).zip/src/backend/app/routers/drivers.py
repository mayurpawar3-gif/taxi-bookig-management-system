"""
Driver-specific routes.
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlmodel import Session
from app.database import get_session
from app.schemas import DriverResponse, NearbyDriversQuery, DriverLocation
from app.models import User, UserRole
from app import crud
from app.deps import get_current_user, require_driver

router = APIRouter(prefix="/drivers", tags=["Drivers"])


@router.get("/nearby", response_model=List[DriverResponse])
def get_nearby_drivers(
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180),
    radius: float = Query(5.0, gt=0, le=50, description="Search radius in kilometers"),
    session: Session = Depends(get_session),
    _: User = Depends(get_current_user),
):
    """
    Find available drivers near a location.
    
    Uses Haversine formula for distance calculation.
    Returns drivers sorted by distance (closest first).
    
    - **latitude**: Location latitude (-90 to 90)
    - **longitude**: Location longitude (-180 to 180)
    - **radius**: Search radius in km (default: 5km, max: 50km)
    """
    drivers = crud.get_nearby_drivers(session, latitude, longitude, radius)
    
    # Convert to response with distance info
    response = []
    for driver in drivers:
        driver_dict = {
            "id": driver.id,
            "name": driver.name,
            "email": driver.email,
            "role": driver.role,
            "phone": driver.phone,
            "vehicle_info": driver.vehicle_info,
            "is_active": driver.is_active,
            "is_available": driver.is_available,
            "created_at": driver.created_at,
            "last_latitude": driver.last_latitude,
            "last_longitude": driver.last_longitude,
        }
        response.append(driver_dict)
    
    return response


@router.post("/location", response_model=DriverResponse)
def update_location(
    location: DriverLocation,
    session: Session = Depends(get_session),
    current_driver: User = Depends(require_driver),
):
    """
    Update driver's current location.
    
    Drivers should call this endpoint periodically to update their position.
    
    - **latitude**: Current latitude
    - **longitude**: Current longitude
    """
    updated_driver = crud.update_driver_location(session, current_driver, location)
    return updated_driver


@router.patch("/availability", response_model=DriverResponse)
def toggle_availability(
    is_available: bool,
    session: Session = Depends(get_session),
    current_driver: User = Depends(require_driver),
):
    """
    Toggle driver availability status.
    
    - **is_available**: True to accept rides, False to stop accepting
    """
    updated_driver = crud.update_user(
        session,
        current_driver,
        is_available=is_available
    )
    return updated_driver


@router.get("/{driver_id}", response_model=DriverResponse)
def get_driver(
    driver_id: int,
    session: Session = Depends(get_session),
    _: User = Depends(get_current_user),
):
    """Get driver details by ID."""
    driver = crud.get_user_by_id(session, driver_id)
    
    if not driver or driver.role != UserRole.DRIVER:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Driver not found",
        )
    
    return driver
