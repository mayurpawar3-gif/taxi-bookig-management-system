"""
Admin-only routes for statistics and management.
"""
from typing import List
from fastapi import APIRouter, Depends
from sqlmodel import Session
from app.database import get_session
from app.schemas import AdminStats, RevenueResponse
from app.models import User, UserRole, RideStatus
from app import crud
from app.deps import require_admin
from sqlmodel import select

router = APIRouter(prefix="/admin", tags=["Admin"])


@router.get("/stats", response_model=AdminStats)
def get_admin_statistics(
    session: Session = Depends(get_session),
    _: User = Depends(require_admin),
):
    """
    Get overall system statistics (admin only).
    
    Returns:
    - Total users, drivers, rides
    - Total and today's revenue
    - Active and completed rides counts
    """
    # Get counts
    total_users = crud.get_total_users(session, role=UserRole.USER)
    total_drivers = crud.get_total_users(session, role=UserRole.DRIVER)
    total_rides = crud.get_total_rides(session)
    active_rides = crud.get_total_rides(session, status=RideStatus.REQUESTED) + \
                   crud.get_total_rides(session, status=RideStatus.ACCEPTED) + \
                   crud.get_total_rides(session, status=RideStatus.IN_PROGRESS)
    
    # Get revenue
    total_revenue = crud.get_total_revenue(session)
    revenue_today = crud.get_revenue_today(session)
    completed_rides_today = crud.get_completed_rides_today(session)
    
    return {
        "total_users": total_users,
        "total_drivers": total_drivers,
        "total_rides": total_rides,
        "total_revenue": total_revenue,
        "active_rides": active_rides,
        "completed_rides_today": completed_rides_today,
        "revenue_today": revenue_today,
    }


@router.get("/revenue", response_model=List[RevenueResponse])
def get_revenue_records(
    skip: int = 0,
    limit: int = 100,
    session: Session = Depends(get_session),
    _: User = Depends(require_admin),
):
    """
    Get revenue records (admin only).
    
    Returns list of all revenue records with pagination.
    """
    from app.models import Revenue
    statement = (
        select(Revenue)
        .order_by(Revenue.created_at.desc())
        .offset(skip)
        .limit(limit)
    )
    revenues = list(session.exec(statement).all())
    return revenues
