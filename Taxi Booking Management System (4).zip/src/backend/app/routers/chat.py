"""
Chat routes with WebSocket support for real-time messaging.
"""
from typing import List, Dict
from fastapi import APIRouter, Depends, HTTPException, status, WebSocket, WebSocketDisconnect
from sqlmodel import Session
from app.database import get_session
from app.schemas import ChatCreate, ChatResponse
from app.models import User, UserRole
from app import crud
from app.deps import get_current_user
import json

router = APIRouter(prefix="/chat", tags=["Chat"])

# Store active WebSocket connections per ride
active_connections: Dict[int, List[WebSocket]] = {}


@router.post("/{ride_id}", response_model=ChatResponse, status_code=status.HTTP_201_CREATED)
def send_message(
    ride_id: int,
    message_data: ChatCreate,
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """
    Send a chat message for a ride.
    
    - **ride_id**: ID of the ride
    - **message**: Message text (1-1000 characters)
    """
    # Verify ride exists
    ride = crud.get_ride_by_id(session, ride_id)
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found",
        )
    
    # Authorization: only ride participants (user, driver) or admin can send messages
    if current_user.role == UserRole.ADMIN:
        pass  # Admin can send to any ride
    elif ride.user_id != current_user.id and ride.driver_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to send messages in this ride",
        )
    
    # Create message
    chat_message = crud.create_chat_message(
        session,
        ride_id,
        current_user.id,
        message_data
    )
    
    # Prepare response
    response = {
        **chat_message.model_dump(),
        "sender_name": current_user.name,
    }
    
    return response


@router.get("/{ride_id}", response_model=List[ChatResponse])
def get_messages(
    ride_id: int,
    limit: int = 100,
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """
    Get chat messages for a ride.
    
    Returns up to `limit` most recent messages.
    """
    # Verify ride exists
    ride = crud.get_ride_by_id(session, ride_id)
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found",
        )
    
    # Authorization: only ride participants or admin can view messages
    if current_user.role == UserRole.ADMIN:
        pass  # Admin can view any ride's messages
    elif ride.user_id != current_user.id and ride.driver_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to view messages in this ride",
        )
    
    # Get messages
    messages = crud.get_ride_chat_messages(session, ride_id, limit)
    
    # Enrich with sender names
    enriched_messages = []
    for msg in messages:
        sender = crud.get_user_by_id(session, msg.sender_id)
        msg_dict = {
            **msg.model_dump(),
            "sender_name": sender.name if sender else "Unknown",
        }
        enriched_messages.append(msg_dict)
    
    return enriched_messages


@router.websocket("/ws/{ride_id}")
async def websocket_endpoint(
    websocket: WebSocket,
    ride_id: int,
):
    """
    WebSocket endpoint for real-time chat.
    
    Connect to this endpoint with a valid JWT token in the query string:
    ws://localhost:8000/chat/ws/{ride_id}?token=<your_jwt_token>
    
    Message format:
    Send: {"type": "chat", "message": "Hello"}
    Receive: {"type": "chat", "sender": "John", "message": "Hello", "timestamp": "..."}
    """
    await websocket.accept()
    
    # Add to active connections
    if ride_id not in active_connections:
        active_connections[ride_id] = []
    active_connections[ride_id].append(websocket)
    
    try:
        while True:
            # Receive message
            data = await websocket.receive_text()
            message_data = json.loads(data)
            
            # Broadcast to all connections in this ride
            for connection in active_connections[ride_id]:
                try:
                    await connection.send_text(json.dumps({
                        "type": "chat",
                        "message": message_data.get("message", ""),
                        "sender": "User",  # In production, extract from JWT
                        "timestamp": str(crud.datetime.utcnow()),
                    }))
                except:
                    pass  # Connection might be closed
                    
    except WebSocketDisconnect:
        # Remove from active connections
        active_connections[ride_id].remove(websocket)
        if not active_connections[ride_id]:
            del active_connections[ride_id]
