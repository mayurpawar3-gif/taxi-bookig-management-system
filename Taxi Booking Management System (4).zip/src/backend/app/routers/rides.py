"""
Ride management routes.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlmodel import Session, select
from app.database import get_session
from app.schemas import (
    RideCreate,
    RideResponse,
    RideWithDetails,
    RideAccept,
    RideComplete,
)
from app.models import User, Ride, UserRole, RideStatus
from app import crud
from app.deps import get_current_user, require_driver

router = APIRouter(prefix="/rides", tags=["Rides"])


@router.post("", response_model=RideResponse, status_code=status.HTTP_201_CREATED)
def create_ride(
    ride_data: RideCreate,
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """
    Create a new ride request.
    
    Users can book a ride by providing pickup and drop-off locations.
    System validates that user doesn't have an active ride already.
    
    - **origin**: Pickup location address
    - **destination**: Drop-off location address
    - **vehicle_type**: Type of vehicle (mini/sedan/suv/xl)
    """
    # Check if user already has an active ride
    if crud.check_user_has_active_ride(session, current_user.id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You already have an active ride. Complete or cancel it first.",
        )
    
    # Create ride
    ride = crud.create_ride(session, current_user.id, ride_data)
    return ride


@router.get("", response_model=List[RideResponse])
def list_rides(
    status: Optional[RideStatus] = Query(None, description="Filter by ride status"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Maximum number of records to return"),
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """
    List rides based on user role.
    
    - **Users**: See their own rides
    - **Drivers**: See rides assigned to them
    - **Admin**: See all rides (with optional status filter)
    """
    if current_user.role == UserRole.ADMIN:
        # Admin can see all rides
        statement = select(Ride)
        if status:
            statement = statement.where(Ride.status == status)
        statement = statement.order_by(Ride.created_at.desc()).offset(skip).limit(limit)
        rides = list(session.exec(statement).all())
    elif current_user.role == UserRole.DRIVER:
        # Drivers see their assigned rides
        rides = crud.get_driver_rides(session, current_user.id, status, skip, limit)
    else:
        # Users see their own rides
        rides = crud.get_user_rides(session, current_user.id, status, skip, limit)
    
    return rides


@router.get("/available", response_model=List[RideWithDetails])
def get_available_rides(
    session: Session = Depends(get_session),
    current_driver: User = Depends(require_driver),
):
    """
    Get all available rides (for drivers).
    
    Returns requested rides that haven't been accepted yet.
    Includes user details for each ride.
    """
    rides = crud.get_available_rides(session)
    
    # Enrich with user details
    enriched_rides = []
    for ride in rides:
        user = crud.get_user_by_id(session, ride.user_id)
        ride_dict = {
            **ride.model_dump(),
            "user_name": user.name if user else None,
            "user_phone": user.phone if user else None,
        }
        enriched_rides.append(ride_dict)
    
    return enriched_rides


@router.get("/{ride_id}", response_model=RideWithDetails)
def get_ride(
    ride_id: int,
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """
    Get ride details by ID.
    
    - **Users**: Can view their own rides
    - **Drivers**: Can view rides assigned to them
    - **Admin**: Can view any ride
    """
    ride = crud.get_ride_by_id(session, ride_id)
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found",
        )
    
    # Authorization check
    if current_user.role == UserRole.ADMIN:
        pass  # Admin can view any ride
    elif current_user.role == UserRole.DRIVER:
        if ride.driver_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not authorized to view this ride",
            )
    else:  # USER role
        if ride.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not authorized to view this ride",
            )
    
    # Enrich with user and driver details
    user = crud.get_user_by_id(session, ride.user_id)
    driver = crud.get_user_by_id(session, ride.driver_id) if ride.driver_id else None
    
    ride_dict = {
        **ride.model_dump(),
        "user_name": user.name if user else None,
        "user_phone": user.phone if user else None,
        "driver_name": driver.name if driver else None,
        "driver_phone": driver.phone if driver else None,
        "driver_vehicle": driver.vehicle_info if driver else None,
    }
    
    return ride_dict


@router.post("/{ride_id}/accept", response_model=RideResponse)
def accept_ride(
    ride_id: int,
    accept_data: RideAccept,
    session: Session = Depends(get_session),
    current_driver: User = Depends(require_driver),
):
    """
    Driver accepts a ride request.
    
    Uses database-level locking to prevent race conditions.
    Only requested rides can be accepted.
    
    - **estimated_time**: Estimated arrival time at pickup
    """
    ride = crud.get_ride_by_id(session, ride_id)
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found",
        )
    
    try:
        accepted_ride = crud.accept_ride(
            session,
            ride,
            current_driver.id,
            accept_data.estimated_time
        )
        return accepted_ride
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )


@router.post("/{ride_id}/start", response_model=RideResponse)
def start_ride(
    ride_id: int,
    session: Session = Depends(get_session),
    current_driver: User = Depends(require_driver),
):
    """
    Driver starts the ride (passenger picked up).
    
    Can only start accepted rides assigned to current driver.
    """
    ride = crud.get_ride_by_id(session, ride_id)
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found",
        )
    
    # Verify driver owns this ride
    if ride.driver_id != current_driver.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to start this ride",
        )
    
    if ride.status != RideStatus.ACCEPTED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Can only start accepted rides",
        )
    
    started_ride = crud.start_ride(session, ride)
    return started_ride


@router.post("/{ride_id}/complete", response_model=RideResponse)
def complete_ride(
    ride_id: int,
    complete_data: RideComplete,
    session: Session = Depends(get_session),
    current_driver: User = Depends(require_driver),
):
    """
    Complete a ride and record payment.
    
    Creates revenue record with commission split.
    Can only complete in-progress rides assigned to current driver.
    
    - **fare**: Final fare amount
    - **distance_km**: Actual distance traveled
    """
    ride = crud.get_ride_by_id(session, ride_id)
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found",
        )
    
    # Verify driver owns this ride
    if ride.driver_id != current_driver.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to complete this ride",
        )
    
    if ride.status != RideStatus.IN_PROGRESS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Can only complete in-progress rides",
        )
    
    completed_ride = crud.complete_ride(
        session,
        ride,
        complete_data.fare,
        complete_data.distance_km
    )
    return completed_ride


@router.post("/{ride_id}/cancel", response_model=RideResponse)
def cancel_ride(
    ride_id: int,
    session: Session = Depends(get_session),
    current_user: User = Depends(get_current_user),
):
    """
    Cancel a ride.
    
    - **Users**: Can cancel their own requested/accepted rides
    - **Drivers**: Can cancel accepted rides (before starting)
    - **Admin**: Can cancel any ride
    """
    ride = crud.get_ride_by_id(session, ride_id)
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found",
        )
    
    # Authorization check
    if current_user.role == UserRole.ADMIN:
        pass  # Admin can cancel any ride
    elif current_user.role == UserRole.DRIVER:
        if ride.driver_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not authorized to cancel this ride",
            )
    else:  # USER role
        if ride.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not authorized to cancel this ride",
            )
    
    # Can't cancel completed rides
    if ride.status == RideStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot cancel completed rides",
        )
    
    # Can't cancel already cancelled rides
    if ride.status == RideStatus.CANCELLED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Ride is already cancelled",
        )
    
    cancelled_ride = crud.cancel_ride(session, ride)
    return cancelled_ride
