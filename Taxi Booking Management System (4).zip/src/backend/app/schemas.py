"""
Pydantic schemas for request/response validation.
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, EmailStr, Field, field_validator
from app.models import UserRole, RideStatus


# ========== Auth Schemas ==========

class UserRegister(BaseModel):
    """Schema for user registration."""
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(..., min_length=6, max_length=100)
    role: UserRole = UserRole.USER
    phone: str = Field(..., pattern=r"^\+?[1-9]\d{9,14}$")
    vehicle_info: Optional[str] = None
    
    @field_validator('vehicle_info')
    def validate_vehicle_info(cls, v, info):
        """Validate vehicle_info is provided for drivers."""
        if info.data.get('role') == UserRole.DRIVER and not v:
            raise ValueError('vehicle_info is required for drivers')
        return v


class UserLogin(BaseModel):
    """Schema for user login."""
    email: EmailStr
    password: str


class Token(BaseModel):
    """Schema for JWT token response."""
    access_token: str
    token_type: str = "bearer"
    user: "UserResponse"


class TokenData(BaseModel):
    """Schema for JWT token data."""
    user_id: int
    email: str
    role: UserRole


# ========== User Schemas ==========

class UserBase(BaseModel):
    """Base user schema."""
    name: str
    email: EmailStr
    role: UserRole
    phone: str


class UserResponse(UserBase):
    """Schema for user response."""
    id: int
    vehicle_info: Optional[str] = None
    is_active: bool
    is_available: bool = False
    created_at: datetime
    
    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    """Schema for user update."""
    name: Optional[str] = None
    phone: Optional[str] = None
    vehicle_info: Optional[str] = None
    is_available: Optional[bool] = None


class DriverLocation(BaseModel):
    """Schema for driver location update."""
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)


class DriverResponse(UserResponse):
    """Schema for driver response with location."""
    last_latitude: Optional[float] = None
    last_longitude: Optional[float] = None


# ========== Ride Schemas ==========

class RideCreate(BaseModel):
    """Schema for creating a ride request."""
    origin: str = Field(..., min_length=3, max_length=200)
    destination: str = Field(..., min_length=3, max_length=200)
    origin_lat: Optional[float] = Field(None, ge=-90, le=90)
    origin_lon: Optional[float] = Field(None, ge=-180, le=180)
    destination_lat: Optional[float] = Field(None, ge=-90, le=90)
    destination_lon: Optional[float] = Field(None, ge=-180, le=180)
    vehicle_type: str = Field(default="sedan")
    metadata: Optional[Dict[str, Any]] = None


class RideUpdate(BaseModel):
    """Schema for ride update."""
    status: Optional[RideStatus] = None
    fare: Optional[float] = Field(None, gt=0)
    distance_km: Optional[float] = Field(None, gt=0)


class RideResponse(BaseModel):
    """Schema for ride response."""
    id: int
    user_id: int
    driver_id: Optional[int] = None
    origin: str
    destination: str
    origin_lat: Optional[float] = None
    origin_lon: Optional[float] = None
    destination_lat: Optional[float] = None
    destination_lon: Optional[float] = None
    status: RideStatus
    fare: Optional[float] = None
    distance_km: Optional[float] = None
    estimated_time: Optional[str] = None
    vehicle_type: str
    metadata: Dict[str, Any]
    created_at: datetime
    updated_at: datetime
    accepted_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class RideWithDetails(RideResponse):
    """Schema for ride with user and driver details."""
    user_name: Optional[str] = None
    user_phone: Optional[str] = None
    driver_name: Optional[str] = None
    driver_phone: Optional[str] = None
    driver_vehicle: Optional[str] = None


class RideAccept(BaseModel):
    """Schema for driver accepting a ride."""
    estimated_time: Optional[str] = "5 min"


class RideComplete(BaseModel):
    """Schema for completing a ride."""
    fare: float = Field(..., gt=0)
    distance_km: float = Field(..., gt=0)


# ========== Chat Schemas ==========

class ChatCreate(BaseModel):
    """Schema for creating a chat message."""
    message: str = Field(..., min_length=1, max_length=1000)


class ChatResponse(BaseModel):
    """Schema for chat message response."""
    id: int
    ride_id: int
    sender_id: int
    message: str
    created_at: datetime
    sender_name: Optional[str] = None
    
    class Config:
        from_attributes = True


# ========== Admin Schemas ==========

class AdminStats(BaseModel):
    """Schema for admin statistics."""
    total_users: int
    total_drivers: int
    total_rides: int
    total_revenue: float
    active_rides: int
    completed_rides_today: int
    revenue_today: float


class RevenueResponse(BaseModel):
    """Schema for revenue response."""
    id: int
    ride_id: int
    amount: float
    driver_commission: Optional[float] = None
    platform_commission: Optional[float] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


# ========== Search/Filter Schemas ==========

class NearbyDriversQuery(BaseModel):
    """Schema for searching nearby drivers."""
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    radius_km: float = Field(default=5.0, gt=0, le=50)


class RideListQuery(BaseModel):
    """Schema for listing rides with filters."""
    status: Optional[RideStatus] = None
    skip: int = Field(default=0, ge=0)
    limit: int = Field(default=20, ge=1, le=100)


# ========== WebSocket Schemas ==========

class WSMessage(BaseModel):
    """Schema for WebSocket messages."""
    type: str  # 'chat', 'status_update', 'location_update'
    data: Dict[str, Any]
