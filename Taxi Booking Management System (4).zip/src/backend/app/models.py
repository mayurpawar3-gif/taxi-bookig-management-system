"""
SQLModel database models.
"""
from datetime import datetime
from typing import Optional
from enum import Enum
from sqlmodel import Field, SQLModel, JSON, Column


class UserRole(str, Enum):
    """User role enumeration."""
    ADMIN = "admin"
    DRIVER = "driver"
    USER = "user"


class RideStatus(str, Enum):
    """Ride status enumeration."""
    REQUESTED = "requested"
    ACCEPTED = "accepted"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class User(SQLModel, table=True):
    """User model for passengers, drivers, and admins."""
    __tablename__ = "users"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True)
    email: str = Field(unique=True, index=True)
    password_hash: str
    role: UserRole = Field(default=UserRole.USER)
    phone: str
    vehicle_info: Optional[str] = Field(default=None)  # For drivers only
    is_active: bool = Field(default=True)
    is_available: bool = Field(default=False)  # For drivers - currently accepting rides
    last_latitude: Optional[float] = Field(default=None)  # For driver location
    last_longitude: Optional[float] = Field(default=None)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class Ride(SQLModel, table=True):
    """Ride/booking model."""
    __tablename__ = "rides"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="users.id", index=True)
    driver_id: Optional[int] = Field(default=None, foreign_key="users.id", index=True)
    
    # Location details
    origin: str
    destination: str
    origin_lat: Optional[float] = None
    origin_lon: Optional[float] = None
    destination_lat: Optional[float] = None
    destination_lon: Optional[float] = None
    
    # Ride details
    status: RideStatus = Field(default=RideStatus.REQUESTED, index=True)
    fare: Optional[float] = Field(default=None)
    distance_km: Optional[float] = Field(default=None)
    estimated_time: Optional[str] = Field(default=None)
    
    # Vehicle type requested
    vehicle_type: Optional[str] = Field(default="sedan")
    
    # Additional metadata as JSON
    metadata: dict = Field(default_factory=dict, sa_column=Column(JSON))
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow, index=True)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    accepted_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class Chat(SQLModel, table=True):
    """Chat message model for ride conversations."""
    __tablename__ = "chats"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    ride_id: int = Field(foreign_key="rides.id", index=True)
    sender_id: int = Field(foreign_key="users.id", index=True)
    message: str
    created_at: datetime = Field(default_factory=datetime.utcnow, index=True)


class Revenue(SQLModel, table=True):
    """Revenue tracking model."""
    __tablename__ = "revenue"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    ride_id: int = Field(foreign_key="rides.id", unique=True, index=True)
    amount: float
    driver_commission: Optional[float] = Field(default=None)  # Amount paid to driver
    platform_commission: Optional[float] = Field(default=None)  # Platform earnings
    created_at: datetime = Field(default_factory=datetime.utcnow, index=True)


class Location(SQLModel, table=True):
    """Location tracking for live ride updates (optional)."""
    __tablename__ = "locations"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    ride_id: int = Field(foreign_key="rides.id", index=True)
    driver_id: int = Field(foreign_key="users.id", index=True)
    lat: float
    lon: float
    recorded_at: datetime = Field(default_factory=datetime.utcnow, index=True)
