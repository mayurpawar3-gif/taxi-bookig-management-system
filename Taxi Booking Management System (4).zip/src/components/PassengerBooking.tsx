import { motion } from "motion/react";
import { MapPin, Target, Car, Users, ArrowLeft, Clock, DollarSign } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { useState } from "react";
import { useAppContext } from "../contexts/AppContext";

const vehicleTypes = [
  {
    id: "mini",
    name: "Mini",
    icon: "🚗",
    capacity: "4 seats",
    price: 120,
    eta: "2 min",
  },
  {
    id: "sedan",
    name: "Sedan",
    icon: "🚙",
    capacity: "4 seats",
    price: 180,
    eta: "3 min",
  },
  {
    id: "suv",
    name: "SUV",
    icon: "🚐",
    capacity: "6 seats",
    price: 280,
    eta: "5 min",
  },
  {
    id: "xl",
    name: "XL",
    icon: "🚌",
    capacity: "8 seats",
    price: 380,
    eta: "7 min",
  },
];

export function PassengerBooking({ onBack, onBook }: { onBack: () => void; onBook: () => void }) {
  const { addRideRequest, users } = useAppContext();
  const [selectedVehicle, setSelectedVehicle] = useState("sedan");
  const [pickup, setPickup] = useState("Marine Drive, South Mumbai");
  const [dropoff, setDropoff] = useState("Andheri East, Mumbai Airport Terminal 2");

  const selected = vehicleTypes.find((v) => v.id === selectedVehicle);
  
  // Simulate logged-in user (first user in the list)
  const currentUser = users[0] || { id: 1, name: "Guest User", phone: "+91 98765 43210" };
  
  const handleBookRide = () => {
    if (selected) {
      // Create ride request that will appear in Driver Dashboard
      addRideRequest({
        passengerId: currentUser.id,
        passengerName: currentUser.name,
        passengerPhone: currentUser.phone,
        pickup,
        dropoff,
        distance: "12.5 km",
        fare: `₹${selected.price}`,
        estimatedTime: selected.eta,
      });
    }
    onBook();
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="p-4 border-b flex items-center gap-3">
        <Button variant="ghost" onClick={onBack} className="rounded-xl">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h2 className="text-xl text-secondary">Book Your Ride</h2>
      </div>

      <div className="flex-1 overflow-auto p-6 space-y-6">
        {/* Location Inputs */}
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Pickup Location</label>
            <div className="relative">
              <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-primary" />
              <Input
                defaultValue="Marine Drive, South Mumbai"
                className="pl-12 h-12 bg-input-background border-border focus:border-primary rounded-xl"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Destination</label>
            <div className="relative">
              <Target className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-destructive" />
              <Input
                defaultValue="Andheri East, Mumbai Airport Terminal 2"
                className="pl-12 h-12 bg-input-background border-border focus:border-primary rounded-xl"
              />
            </div>
          </div>
        </div>

        {/* Vehicle Selection */}
        <div className="space-y-3">
          <h3 className="text-lg text-secondary">Choose Vehicle Type</h3>
          <div className="grid grid-cols-2 gap-3">
            {vehicleTypes.map((vehicle) => (
              <motion.div
                key={vehicle.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card
                  onClick={() => setSelectedVehicle(vehicle.id)}
                  className={`p-4 cursor-pointer transition-all ${
                    selectedVehicle === vehicle.id
                      ? "border-2 border-primary bg-primary/5 shadow-lg shadow-primary/10"
                      : "border-border hover:border-primary/50 hover:bg-primary/5"
                  }`}
                >
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <span className="text-3xl">{vehicle.icon}</span>
                      {selectedVehicle === vehicle.id && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-6 h-6 bg-primary rounded-full flex items-center justify-center"
                        >
                          <div className="w-2 h-2 bg-secondary rounded-full" />
                        </motion.div>
                      )}
                    </div>
                    <div>
                      <p className="text-sm text-secondary">{vehicle.name}</p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Users className="w-3 h-3" />
                        {vehicle.capacity}
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      <p className="text-lg text-secondary">₹{vehicle.price}</p>
                      <Badge variant="secondary" className="text-xs">
                        <Clock className="w-3 h-3 mr-1" />
                        {vehicle.eta}
                      </Badge>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Fare Breakdown */}
        <Card className="p-5 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
          <h3 className="text-sm text-muted-foreground mb-3">Fare Breakdown</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Base Fare</span>
              <span className="text-secondary">₹{selected?.price}.00</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Service Fee</span>
              <span className="text-secondary">₹25.00</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Distance (12.5 km)</span>
              <span className="text-secondary">₹75.00</span>
            </div>
            <div className="border-t border-border/50 pt-2 mt-2">
              <div className="flex justify-between">
                <span className="text-secondary">Total Fare</span>
                <div className="flex items-center gap-1">
                  <DollarSign className="w-4 h-4 text-primary" />
                  <span className="text-xl text-secondary">
                    ₹{(selected?.price || 0) + 100}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Book Button */}
      <div className="p-6 border-t bg-white">
        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Button
            onClick={onBook}
            className="w-full h-14 bg-primary hover:bg-accent text-secondary rounded-xl shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-accent/30 transition-all duration-300"
          >
            Book {selected?.name} Now
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
