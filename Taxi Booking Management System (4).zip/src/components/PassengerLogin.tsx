import { motion } from "motion/react";
import { Mail, Lock, Phone, ArrowLeft, AlertCircle, CheckCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { useState } from "react";

export function PassengerLogin({ onBack, onLogin, onSignup }: { onBack: () => void; onLogin: () => void; onSignup?: () => void }) {
  const [isLoading, setIsLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotPasswordSent, setForgotPasswordSent] = useState(false);
  
  // Email login state
  const [email, setEmail] = useState("");
  const [emailPassword, setEmailPassword] = useState("");
  const [emailError, setEmailError] = useState("");
  
  // Phone login state
  const [phone, setPhone] = useState("");
  const [phonePassword, setPhonePassword] = useState("");
  const [phoneError, setPhoneError] = useState("");

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePhone = (phone: string) => {
    const phoneRegex = /^(\+91|0)?[6-9]\d{9}$/;
    return phoneRegex.test(phone.replace(/\s+/g, ''));
  };

  const validatePassword = (password: string) => {
    return password.length >= 6;
  };

  const handleEmailLogin = () => {
    setEmailError("");
    
    if (!email || !emailPassword) {
      setEmailError("Please fill in all fields");
      return;
    }
    
    if (!validateEmail(email)) {
      setEmailError("Please enter a valid email address");
      return;
    }
    
    if (!validatePassword(emailPassword)) {
      setEmailError("Password must be at least 6 characters");
      return;
    }
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1000);
  };

  const handlePhoneLogin = () => {
    setPhoneError("");
    
    if (!phone || !phonePassword) {
      setPhoneError("Please fill in all fields");
      return;
    }
    
    if (!validatePhone(phone)) {
      setPhoneError("Please enter a valid Indian phone number");
      return;
    }
    
    if (!validatePassword(phonePassword)) {
      setPhoneError("Password must be at least 6 characters");
      return;
    }
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1000);
  };

  const handleForgotPassword = () => {
    setForgotPasswordSent(true);
    setTimeout(() => {
      setForgotPasswordSent(false);
      setShowForgotPassword(false);
    }, 3000);
  };

  return (
    <div className="h-full bg-white flex flex-col p-6 overflow-auto">
      <Button
        variant="ghost"
        onClick={onBack}
        className="self-start mb-6 -ml-2"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        Back
      </Button>

      <div className="flex-1 flex flex-col justify-center max-w-md mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl text-secondary mb-2">Welcome Back</h1>
          <p className="text-muted-foreground">Sign in to continue your journey</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Tabs defaultValue="email" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="email">Email</TabsTrigger>
              <TabsTrigger value="phone">Phone</TabsTrigger>
            </TabsList>

            <TabsContent value="email" className="space-y-4">
              {emailError && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg flex items-center gap-2"
                >
                  <AlertCircle className="w-4 h-4 text-destructive" />
                  <p className="text-sm text-destructive">{emailError}</p>
                </motion.div>
              )}
              
              <div className="space-y-2">
                <label className="text-sm text-foreground">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-foreground">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={emailPassword}
                    onChange={(e) => setEmailPassword(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              </div>

              <Button
                onClick={handleEmailLogin}
                disabled={isLoading}
                className="w-full h-12 bg-primary hover:bg-accent text-secondary rounded-xl shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300"
              >
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>
            </TabsContent>

            <TabsContent value="phone" className="space-y-4">
              {phoneError && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg flex items-center gap-2"
                >
                  <AlertCircle className="w-4 h-4 text-destructive" />
                  <p className="text-sm text-destructive">{phoneError}</p>
                </motion.div>
              )}
              
              <div className="space-y-2">
                <label className="text-sm text-foreground">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-foreground">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={phonePassword}
                    onChange={(e) => setPhonePassword(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              </div>

              <Button
                onClick={handlePhoneLogin}
                disabled={isLoading}
                className="w-full h-12 bg-primary hover:bg-accent text-secondary rounded-xl shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300"
              >
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>
            </TabsContent>
          </Tabs>

          <div className="mt-4 text-center">
            <button 
              onClick={() => setShowForgotPassword(true)}
              className="text-sm text-primary hover:text-accent transition-colors"
            >
              Forgot Password?
            </button>
          </div>

          <div className="mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              Don't have an account?{" "}
              <button 
                onClick={onSignup}
                className="text-primary hover:text-accent transition-colors"
              >
                Sign Up
              </button>
            </p>
          </div>
        </motion.div>
      </div>

      {/* Forgot Password Dialog */}
      <Dialog open={showForgotPassword} onOpenChange={setShowForgotPassword}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-secondary">Forgot Password?</DialogTitle>
            <DialogDescription>
              {forgotPasswordSent ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-6 text-center space-y-4"
                >
                  <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle className="w-8 h-8 text-success" />
                  </div>
                  <div>
                    <p className="text-foreground">Password reset link sent!</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Please check your email/phone for the password reset link.
                    </p>
                  </div>
                </motion.div>
              ) : (
                <div className="space-y-4 py-4">
                  <p className="text-foreground">
                    Don't worry! Enter your email or phone number and we'll send you a link to reset your password.
                  </p>
                  <div className="space-y-2">
                    <label className="text-sm text-foreground">Email or Phone</label>
                    <Input
                      placeholder="your@email.com or +91 98765 43210"
                      className="h-12 bg-input-background border-border focus:border-primary"
                    />
                  </div>
                  <Button
                    onClick={handleForgotPassword}
                    className="w-full h-12 bg-primary hover:bg-accent text-secondary rounded-xl"
                  >
                    Send Reset Link
                  </Button>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </div>
  );
}
