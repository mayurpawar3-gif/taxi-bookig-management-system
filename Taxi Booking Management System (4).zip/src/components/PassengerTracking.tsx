import { motion } from "motion/react";
import { Phone, MessageSquare, Navigation, MapPin, User, Star } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState, useEffect } from "react";

export function PassengerTracking({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(15);
  const [eta, setEta] = useState(8);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 1000);
          return 100;
        }
        return prev + 2;
      });
      setEta((prev) => Math.max(0, prev - 0.15));
    }, 1000);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Map View */}
      <div className="flex-1 relative bg-gradient-to-br from-muted/20 to-muted/40">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1669508886393-d3ec02f4a330?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwc3RyZWV0JTIwbWFwJTIwbmF2aWdhdGlvbnxlbnwxfHx8fDE3NTk5MDk0MjZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Route Map"
          className="w-full h-full object-cover opacity-40"
        />

        {/* Animated Route Line */}
        <svg className="absolute inset-0 w-full h-full" style={{ pointerEvents: "none" }}>
          <motion.path
            d="M 100 400 Q 300 200 500 300"
            stroke="#FFB400"
            strokeWidth="4"
            fill="none"
            strokeDasharray="10 5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: progress / 100 }}
            transition={{ duration: 0.5 }}
          />
        </svg>

        {/* Pickup Pin */}
        <div className="absolute bottom-1/3 left-1/4 transform -translate-x-1/2">
          <div className="w-12 h-12 bg-success rounded-full flex items-center justify-center shadow-xl">
            <MapPin className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* Destination Pin */}
        <div className="absolute top-1/4 right-1/3 transform translate-x-1/2">
          <div className="w-12 h-12 bg-destructive rounded-full flex items-center justify-center shadow-xl">
            <MapPin className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* Moving Driver Icon */}
        <motion.div
          animate={{
            x: [0, 100, 200],
            y: [0, -50, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear",
          }}
          className="absolute bottom-1/2 left-1/4"
        >
          <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center shadow-xl transform rotate-45">
            <Navigation className="w-5 h-5 text-primary -rotate-45" />
          </div>
        </motion.div>

        {/* ETA Badge */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="absolute top-6 left-1/2 transform -translate-x-1/2"
        >
          <Badge className="bg-secondary text-white px-6 py-3 shadow-xl border-none text-base">
            Arriving in {Math.ceil(eta)} minutes
          </Badge>
        </motion.div>
      </div>

      {/* Bottom Sheet */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="bg-white rounded-t-3xl shadow-2xl p-6 space-y-4"
      >
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Trip Progress</span>
            <span className="text-primary">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Driver Card */}
        <Card className="p-4 border-primary/20 bg-gradient-to-r from-primary/5 to-accent/5">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16 border-2 border-primary shadow-lg">
              <AvatarFallback className="bg-primary text-secondary text-xl">
                JD
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <p className="text-lg text-secondary">Rohan Mehta</p>
                <div className="flex items-center gap-0.5">
                  <Star className="w-4 h-4 fill-primary text-primary" />
                  <span className="text-sm">4.9</span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-1">Maruti Ertiga • MH 02 BX 5678</p>
              <Badge variant="secondary" className="text-xs">
                3.2 km away
              </Badge>
            </div>
          </div>

          {/* Contact Buttons */}
          <div className="grid grid-cols-2 gap-3 mt-4">
            <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              <Button
                variant="outline"
                className="w-full gap-2 hover:bg-success/10 hover:text-success hover:border-success"
              >
                <Phone className="w-4 h-4" />
                Call Driver
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              <Button
                variant="outline"
                className="w-full gap-2 hover:bg-primary/10 hover:text-primary hover:border-primary"
              >
                <MessageSquare className="w-4 h-4" />
                Message
              </Button>
            </motion.div>
          </div>
        </Card>

        {/* Trip Details */}
        <Card className="p-4">
          <h3 className="text-sm text-muted-foreground mb-3">Trip Details</h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="w-4 h-4 text-success" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Pickup</p>
                <p className="text-sm text-secondary">Marine Drive, South Mumbai</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-destructive/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="w-4 h-4 text-destructive" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Destination</p>
                <p className="text-sm text-secondary">Andheri East, Mumbai Airport T2</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Cancel Button */}
        <Button
          variant="ghost"
          className="w-full text-destructive hover:bg-destructive/10 hover:text-destructive"
        >
          Cancel Trip
        </Button>
      </motion.div>
    </div>
  );
}
