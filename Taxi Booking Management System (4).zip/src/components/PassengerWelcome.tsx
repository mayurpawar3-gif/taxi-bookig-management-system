import { motion } from "motion/react";
import { Car, Shield, Clock, CreditCard, MapPin, Star } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function PassengerWelcome({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <div className="h-full flex flex-col overflow-auto bg-gradient-to-br from-secondary via-secondary to-secondary/90">
      {/* Hero Section */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center relative overflow-hidden">
        {/* Animated Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-20 left-20 w-32 h-32 border-4 border-primary rounded-full animate-pulse" />
          <div className="absolute bottom-20 right-20 w-24 h-24 border-4 border-accent rounded-full animate-pulse delay-300" />
          <div className="absolute top-1/2 left-1/3 w-16 h-16 border-4 border-primary rounded-full animate-pulse delay-700" />
        </div>

        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", duration: 0.8 }}
          className="mb-8 relative"
        >
          <div className="w-32 h-32 bg-primary rounded-3xl flex items-center justify-center shadow-2xl shadow-primary/40 relative overflow-hidden">
            <motion.div
              animate={{ rotate: [0, 5, -5, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Car className="w-16 h-16 text-secondary" />
            </motion.div>
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-tr from-accent/20 to-transparent" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="max-w-2xl"
        >
          <h1 className="text-5xl text-white mb-4">Ride Easy, Arrive Safely</h1>
          <p className="text-xl text-muted mb-8">
            Your trusted taxi booking system. Professional drivers, safe rides, best prices.
          </p>

          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={onGetStarted}
              className="h-14 px-12 bg-primary hover:bg-accent text-secondary rounded-2xl shadow-2xl shadow-primary/40 hover:shadow-3xl hover:shadow-accent/50 transition-all duration-300 relative overflow-hidden group"
            >
              <span className="relative z-10">Get Started</span>
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-accent to-primary opacity-0 group-hover:opacity-100 transition-opacity"
                initial={false}
              />
            </Button>
          </motion.div>
        </motion.div>
      </div>

      {/* Features Section */}
      <div className="bg-white/5 backdrop-blur-lg border-t border-white/10 p-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6"
          >
            {[
              { icon: Shield, label: "Safe & Secure", color: "text-success" },
              { icon: Clock, label: "24/7 Available", color: "text-primary" },
              { icon: CreditCard, label: "Easy Payment", color: "text-accent" },
              { icon: Star, label: "Top Rated", color: "text-primary" },
            ].map((feature, index) => (
              <motion.div
                key={feature.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 + index * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
                className="flex flex-col items-center gap-3 p-4 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
              >
                <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center relative group">
                  <feature.icon className={`w-6 h-6 ${feature.color}`} />
                  <motion.div
                    className="absolute inset-0 rounded-xl bg-primary opacity-0 group-hover:opacity-20 transition-opacity"
                    style={{ filter: "blur(8px)" }}
                  />
                </div>
                <p className="text-sm text-white text-center">{feature.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
