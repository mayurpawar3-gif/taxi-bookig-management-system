import { motion } from "motion/react";
import { Mail, Lock, Phone, Upload, Car, FileText, User, AlertCircle, CheckCircle, X } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Card } from "./ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { useState } from "react";
import { useAppContext } from "../contexts/AppContext";

export function DriverLogin({ onLogin }: { onLogin: (driverName: string) => void }) {
  const { addDriver } = useAppContext();
  const [isLoading, setIsLoading] = useState(false);
  const [isRegistration, setIsRegistration] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotPasswordSent, setForgotPasswordSent] = useState(false);
  const [showRegistrationSuccess, setShowRegistrationSuccess] = useState(false);
  
  // Login state
  const [email, setEmail] = useState("");
  const [emailPassword, setEmailPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [phonePassword, setPhonePassword] = useState("");
  const [loginError, setLoginError] = useState("");
  
  // Registration state
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [vehicleModel, setVehicleModel] = useState("");
  const [licensePlate, setLicensePlate] = useState("");
  const [vehicleYear, setVehicleYear] = useState("");
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [licensePhoto, setLicensePhoto] = useState<string | null>(null);
  const [regError, setRegError] = useState("");

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePhone = (phone: string) => {
    const phoneRegex = /^(\+91|0)?[6-9]\d{9}$/;
    return phoneRegex.test(phone.replace(/\s+/g, ''));
  };

  const validatePassword = (password: string) => {
    return password.length >= 6;
  };

  const handleEmailLogin = () => {
    setLoginError("");
    
    if (!email || !emailPassword) {
      setLoginError("Please fill in all fields");
      return;
    }
    
    if (!validateEmail(email)) {
      setLoginError("Please enter a valid email address");
      return;
    }
    
    if (!validatePassword(emailPassword)) {
      setLoginError("Password must be at least 6 characters");
      return;
    }
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin("Arjun Kumar");
    }, 1000);
  };

  const handlePhoneLogin = () => {
    setLoginError("");
    
    if (!phone || !phonePassword) {
      setLoginError("Please fill in all fields");
      return;
    }
    
    if (!validatePhone(phone)) {
      setLoginError("Please enter a valid Indian phone number");
      return;
    }
    
    if (!validatePassword(phonePassword)) {
      setLoginError("Password must be at least 6 characters");
      return;
    }
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin("Arjun Kumar");
    }, 1000);
  };

  const handleForgotPassword = () => {
    setForgotPasswordSent(true);
    setTimeout(() => {
      setForgotPasswordSent(false);
      setShowForgotPassword(false);
    }, 3000);
  };

  const handleProfilePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLicensePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLicensePhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRegistrationSubmit = () => {
    setRegError("");
    
    if (!regName || !regEmail || !regPhone || !regPassword || !vehicleModel || !licensePlate || !vehicleYear) {
      setRegError("Please fill in all required fields");
      return;
    }
    
    if (!validateEmail(regEmail)) {
      setRegError("Please enter a valid email address");
      return;
    }
    
    if (!validatePhone(regPhone)) {
      setRegError("Please enter a valid Indian phone number");
      return;
    }
    
    if (!validatePassword(regPassword)) {
      setRegError("Password must be at least 6 characters");
      return;
    }
    
    if (!profilePhoto || !licensePhoto) {
      setRegError("Please upload profile photo and driver's license");
      return;
    }
    
    // Add driver to global context (will appear in Admin Dashboard)
    addDriver({
      name: regName,
      email: regEmail,
      phone: regPhone,
      vehicle: `${vehicleModel} • ${licensePlate}`,
    });
    
    // Show success dialog and then redirect to login
    setShowRegistrationSuccess(true);
    setTimeout(() => {
      setShowRegistrationSuccess(false);
      setIsRegistration(false);
      // Reset form
      setRegName("");
      setRegEmail("");
      setRegPhone("");
      setRegPassword("");
      setVehicleModel("");
      setLicensePlate("");
      setVehicleYear("");
      setProfilePhoto(null);
      setLicensePhoto(null);
    }, 2500);
  };

  if (isRegistration) {
    return (
      <div className="h-full bg-white flex flex-col p-6 overflow-auto">
        <Button
          variant="ghost"
          onClick={() => setIsRegistration(false)}
          className="self-start mb-6 -ml-2"
        >
          ← Back to Login
        </Button>

        <div className="flex-1 flex flex-col max-w-2xl mx-auto w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <h1 className="text-3xl text-secondary mb-2">Driver Registration</h1>
            <p className="text-muted-foreground">Complete your profile to start earning with RideNow India</p>
          </motion.div>

          {regError && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 bg-destructive/10 border border-destructive/20 rounded-lg flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4 text-destructive" />
              <p className="text-sm text-destructive">{regError}</p>
            </motion.div>
          )}

          <div className="space-y-4">
            {/* Profile Photo Upload */}
            <Card className="p-6 border-2 border-dashed hover:border-primary transition-all">
              <input
                type="file"
                id="profilePhoto"
                accept="image/*"
                onChange={handleProfilePhotoUpload}
                className="hidden"
              />
              <label htmlFor="profilePhoto" className="cursor-pointer">
                <div className="flex items-center gap-4">
                  {profilePhoto ? (
                    <div className="relative w-16 h-16 rounded-full overflow-hidden">
                      <img src={profilePhoto} alt="Profile" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <Upload className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  ) : (
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                      <Upload className="w-8 h-8 text-primary" />
                    </div>
                  )}
                  <div>
                    <p className="text-sm mb-1">Profile Photo *</p>
                    <p className="text-xs text-muted-foreground">
                      {profilePhoto ? "Click to change photo" : "Click to upload"}
                    </p>
                  </div>
                </div>
              </label>
            </Card>

            {/* License Upload */}
            <Card className="p-6 border-2 border-dashed hover:border-primary transition-all">
              <input
                type="file"
                id="licensePhoto"
                accept="image/*"
                onChange={handleLicensePhotoUpload}
                className="hidden"
              />
              <label htmlFor="licensePhoto" className="cursor-pointer">
                <div className="flex items-center gap-4">
                  {licensePhoto ? (
                    <div className="relative w-16 h-16 rounded-xl overflow-hidden">
                      <img src={licensePhoto} alt="License" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <Upload className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  ) : (
                    <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center">
                      <FileText className="w-8 h-8 text-primary" />
                    </div>
                  )}
                  <div>
                    <p className="text-sm mb-1">Driver's License *</p>
                    <p className="text-xs text-muted-foreground">
                      {licensePhoto ? "Click to change" : "Upload front & back"}
                    </p>
                  </div>
                </div>
              </label>
            </Card>

            {/* Personal Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm">Full Name *</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    placeholder="e.g., Arjun Kumar"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm">Email Address *</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm">Phone Number *</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm">Password *</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="Min. 6 characters"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>
              </div>
            </div>

            {/* Vehicle Details */}
            <div className="pt-4 border-t">
              <h3 className="text-lg text-secondary mb-4">Vehicle Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm">Vehicle Make & Model *</label>
                  <div className="relative">
                    <Car className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      placeholder="e.g., Maruti Swift Dzire"
                      value={vehicleModel}
                      onChange={(e) => setVehicleModel(e.target.value)}
                      className="pl-10 h-12 bg-input-background border-border focus:border-primary"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm">License Plate *</label>
                  <Input
                    placeholder="MH-01-AB-1234"
                    value={licensePlate}
                    onChange={(e) => setLicensePlate(e.target.value)}
                    className="h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm">Vehicle Year *</label>
                  <Input
                    placeholder="2020"
                    value={vehicleYear}
                    onChange={(e) => setVehicleYear(e.target.value)}
                    className="h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>
              </div>
            </div>

            <Button
              onClick={handleRegistrationSubmit}
              className="w-full h-12 bg-primary hover:bg-accent text-secondary rounded-xl shadow-lg mt-6"
            >
              Submit Application
            </Button>
          </div>
        </div>

        {/* Registration Success Dialog */}
        <Dialog open={showRegistrationSuccess} onOpenChange={setShowRegistrationSuccess}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-secondary">Registration Successful!</DialogTitle>
              <DialogDescription>
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-6 text-center space-y-4"
                >
                  <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle className="w-8 h-8 text-success" />
                  </div>
                  <div>
                    <p className="text-foreground">Your application has been submitted!</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      We're reviewing your documents. You'll be redirected to login shortly.
                    </p>
                  </div>
                </motion.div>
              </DialogDescription>
            </DialogHeader>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="h-full bg-white flex flex-col p-6 overflow-auto">
      <div className="flex-1 flex flex-col justify-center max-w-md mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mb-4">
            <Car className="w-8 h-8 text-secondary" />
          </div>
          <h1 className="text-3xl text-secondary mb-2">Driver Portal</h1>
          <p className="text-muted-foreground">Sign in to start driving with RideNow India</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          {loginError && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 bg-destructive/10 border border-destructive/20 rounded-lg flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4 text-destructive" />
              <p className="text-sm text-destructive">{loginError}</p>
            </motion.div>
          )}

          <Tabs defaultValue="email" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="email">Email</TabsTrigger>
              <TabsTrigger value="phone">Phone</TabsTrigger>
            </TabsList>

            <TabsContent value="email" className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="driver@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={emailPassword}
                    onChange={(e) => setEmailPassword(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>
              </div>

              <Button
                onClick={handleEmailLogin}
                disabled={isLoading}
                className="w-full h-12 bg-primary hover:bg-accent text-secondary rounded-xl shadow-lg shadow-primary/20"
              >
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>
            </TabsContent>

            <TabsContent value="phone" className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={phonePassword}
                    onChange={(e) => setPhonePassword(e.target.value)}
                    className="pl-10 h-12 bg-input-background border-border focus:border-primary"
                  />
                </div>
              </div>

              <Button
                onClick={handlePhoneLogin}
                disabled={isLoading}
                className="w-full h-12 bg-primary hover:bg-accent text-secondary rounded-xl shadow-lg shadow-primary/20"
              >
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>
            </TabsContent>
          </Tabs>

          <div className="mt-4 text-center">
            <button 
              onClick={() => setShowForgotPassword(true)}
              className="text-sm text-primary hover:text-accent transition-colors"
            >
              Forgot Password?
            </button>
          </div>

          <div className="mt-8 text-center space-y-4">
            <p className="text-sm text-muted-foreground">
              New driver?{" "}
              <button
                onClick={() => setIsRegistration(true)}
                className="text-primary hover:text-accent transition-colors"
              >
                Register Now
              </button>
            </p>
          </div>
        </motion.div>
      </div>

      {/* Forgot Password Dialog */}
      <Dialog open={showForgotPassword} onOpenChange={setShowForgotPassword}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-secondary">Forgot Password?</DialogTitle>
            <DialogDescription>
              {forgotPasswordSent ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-6 text-center space-y-4"
                >
                  <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle className="w-8 h-8 text-success" />
                  </div>
                  <div>
                    <p className="text-foreground">Password reset link sent!</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Please check your email/phone for the password reset link.
                    </p>
                  </div>
                </motion.div>
              ) : (
                <div className="space-y-4 py-4">
                  <p className="text-foreground">
                    Enter your registered email or phone number to receive a password reset link.
                  </p>
                  <div className="space-y-2">
                    <label className="text-sm text-foreground">Email or Phone</label>
                    <Input
                      placeholder="your@email.com or +91 98765 43210"
                      className="h-12 bg-input-background border-border focus:border-primary"
                    />
                  </div>
                  <Button
                    onClick={handleForgotPassword}
                    className="w-full h-12 bg-primary hover:bg-accent text-secondary rounded-xl"
                  >
                    Send Reset Link
                  </Button>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </div>
  );
}
