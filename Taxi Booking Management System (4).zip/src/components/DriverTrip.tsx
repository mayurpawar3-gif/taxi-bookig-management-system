import { motion } from "motion/react";
import {
  Navigation,
  MapPin,
  Phone,
  MessageSquare,
  User,
  CheckCircle,
} from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState } from "react";

export function DriverTrip({ onEndTrip }: { onEndTrip: () => void }) {
  const [tripProgress, setTripProgress] = useState(35);

  const handleCompleteTrip = () => {
    setTripProgress(100);
    setTimeout(onEndTrip, 1500);
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Navigation Map */}
      <div className="flex-1 relative bg-gradient-to-br from-muted/20 to-muted/40">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1669508886393-d3ec02f4a330?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwc3RyZWV0JTIwbWFwJTIwbmF2aWdhdGlvbnxlbnwxfHx8fDE3NTk5MDk0MjZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Navigation Map"
          className="w-full h-full object-cover opacity-40"
        />

        {/* Animated Route */}
        <svg className="absolute inset-0 w-full h-full" style={{ pointerEvents: "none" }}>
          <motion.path
            d="M 150 350 Q 300 250 450 300"
            stroke="#FFB400"
            strokeWidth="6"
            fill="none"
            strokeDasharray="12 8"
            animate={{ strokeDashoffset: [0, -20] }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
        </svg>

        {/* Current Location Indicator */}
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
        >
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center shadow-2xl shadow-primary/40 relative">
            <Navigation className="w-8 h-8 text-secondary" />
            <motion.div
              animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 bg-primary rounded-full"
            />
          </div>
        </motion.div>

        {/* Destination Marker */}
        <div className="absolute top-1/4 right-1/4">
          <div className="w-12 h-12 bg-destructive rounded-full flex items-center justify-center shadow-xl">
            <MapPin className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* Status Badge */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="absolute top-6 left-1/2 transform -translate-x-1/2"
        >
          <Badge className="bg-success text-white px-6 py-3 shadow-xl border-none text-base">
            Trip in Progress
          </Badge>
        </motion.div>

        {/* Navigation Instructions */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="absolute bottom-6 left-6 right-6"
        >
          <Card className="p-4 bg-white/95 backdrop-blur-lg border-primary/20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                <Navigation className="w-6 h-6 text-secondary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-secondary mb-1">Turn right on Airport Road</p>
                <p className="text-xs text-muted-foreground">In 500 meters</p>
              </div>
              <div className="text-right">
                <p className="text-base text-primary">3.2 km</p>
                <p className="text-xs text-muted-foreground">8 min</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Bottom Sheet */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="bg-white rounded-t-3xl shadow-2xl p-6 space-y-4"
      >
        {/* Trip Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Trip Progress</span>
            <span className="text-primary">{Math.round(tripProgress)}%</span>
          </div>
          <Progress value={tripProgress} className="h-2" />
        </div>

        {/* Passenger Info */}
        <Card className="p-4 border-primary/20 bg-gradient-to-r from-primary/5 to-accent/5">
          <div className="flex items-center gap-4">
            <Avatar className="w-14 h-14 border-2 border-primary shadow-lg">
              <AvatarFallback className="bg-primary text-secondary">
                SP
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="text-base text-secondary mb-1">Sarah Passenger</p>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">Premium</Badge>
                <span className="text-xs text-muted-foreground">★ 4.8 rating</span>
              </div>
            </div>
          </div>

          {/* Contact Buttons */}
          <div className="grid grid-cols-2 gap-3 mt-4">
            <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              <Button
                variant="outline"
                className="w-full gap-2 hover:bg-success/10 hover:text-success hover:border-success"
              >
                <Phone className="w-4 h-4" />
                Call
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              <Button
                variant="outline"
                className="w-full gap-2 hover:bg-primary/10 hover:text-primary hover:border-primary"
              >
                <MessageSquare className="w-4 h-4" />
                Message
              </Button>
            </motion.div>
          </div>
        </Card>

        {/* Trip Details */}
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <MapPin className="w-4 h-4 text-success" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">Pickup</p>
              <p className="text-sm text-secondary">123 Main Street, Downtown</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-destructive/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <MapPin className="w-4 h-4 text-destructive" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">Destination</p>
              <p className="text-sm text-secondary">456 Airport Road, Terminal 2</p>
            </div>
          </div>
        </div>

        {/* Complete Trip Button */}
        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Button
            onClick={handleCompleteTrip}
            className="w-full h-14 bg-success hover:bg-success/90 text-white rounded-xl shadow-lg shadow-success/20 hover:shadow-xl hover:shadow-success/30 transition-all duration-300 gap-2"
          >
            <CheckCircle className="w-5 h-5" />
            Complete Trip
          </Button>
        </motion.div>

        {/* Emergency Button */}
        <Button
          variant="ghost"
          className="w-full text-destructive hover:bg-destructive/10 hover:text-destructive"
        >
          Report Emergency
        </Button>
      </motion.div>
    </div>
  );
}
