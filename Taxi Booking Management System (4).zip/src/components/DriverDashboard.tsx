import { motion, AnimatePresence } from "motion/react";
import {
  DollarSign,
  TrendingUp,
  MapPin,
  Clock,
  Star,
  Gift,
  Bell,
  X,
} from "lucide-react";
import { Card } from "./ui/card";
import { Switch } from "./ui/switch";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { useState } from "react";

const todayTrips = [
  { id: 1, from: "Marine Drive", to: "Andheri Airport", fare: 280, time: "10:30 AM" },
  { id: 2, from: "Juhu Beach", to: "BKC", fare: 150, time: "11:45 AM" },
  { id: 3, from: "CSMT", to: "Gateway of India", fare: 120, time: "2:15 PM" },
];

const notifications = [
  { id: 1, title: "New Ride Request", message: "Priya is requesting a ride from BKC to Andheri", time: "2 min ago", type: "request" },
  { id: 2, title: "Payment Received", message: "₹280 added to your wallet", time: "15 min ago", type: "payment" },
  { id: 3, title: "Weekly Target", message: "Complete 3 more rides to reach your weekly goal!", time: "1 hour ago", type: "info" },
];

interface DriverDashboardProps {
  onNewRide: () => void;
  driverName?: string;
}

export function DriverDashboard({ onNewRide, driverName = "Arjun" }: DriverDashboardProps) {
  const [isOnline, setIsOnline] = useState(true);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showBonusDetails, setShowBonusDetails] = useState(false);

  return (
    <div className="h-full flex flex-col bg-white overflow-auto">
      {/* Header with Status Toggle */}
      <div className="p-6 bg-gradient-to-br from-secondary to-secondary/90 text-white">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl mb-1">Welcome Back, {driverName}!</h1>
            <p className="text-sm text-muted">Ready to earn today?</p>
          </div>
          <div className="relative">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-3 bg-white/10 rounded-xl hover:bg-white/20 transition-colors"
            >
              <Bell className="w-6 h-6" />
              <div className="absolute top-2 right-2 w-2 h-2 bg-destructive rounded-full animate-pulse" />
            </motion.button>

            {/* Notification Dropdown */}
            <AnimatePresence>
              {showNotifications && (
                <motion.div
                  initial={{ opacity: 0, y: -10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -10, scale: 0.95 }}
                  className="absolute right-0 top-full mt-2 w-80 bg-white rounded-xl shadow-2xl border border-border overflow-hidden z-50"
                >
                  <div className="p-4 border-b border-border flex items-center justify-between bg-muted/30">
                    <h3 className="text-sm text-secondary">Notifications</h3>
                    <button 
                      onClick={() => setShowNotifications(false)}
                      className="p-1 hover:bg-muted rounded-lg transition-colors"
                    >
                      <X className="w-4 h-4 text-muted-foreground" />
                    </button>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {notifications.map((notif) => (
                      <motion.div
                        key={notif.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="p-4 border-b border-border hover:bg-muted/50 transition-colors cursor-pointer"
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            notif.type === 'request' ? 'bg-primary/10' :
                            notif.type === 'payment' ? 'bg-success/10' : 'bg-muted'
                          }`}>
                            {notif.type === 'request' && <MapPin className="w-4 h-4 text-primary" />}
                            {notif.type === 'payment' && <DollarSign className="w-4 h-4 text-success" />}
                            {notif.type === 'info' && <Bell className="w-4 h-4 text-muted-foreground" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-secondary">{notif.title}</p>
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{notif.message}</p>
                            <p className="text-xs text-muted-foreground mt-1">{notif.time}</p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  <div className="p-3 bg-muted/30 text-center">
                    <button className="text-xs text-primary hover:text-accent transition-colors">
                      View All Notifications
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Online/Offline Toggle */}
        <Card className="p-4 bg-white/10 backdrop-blur-lg border-white/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`w-3 h-3 rounded-full ${
                  isOnline ? "bg-success animate-pulse" : "bg-muted"
                }`}
              />
              <div>
                <p className="text-white">
                  {isOnline ? "You're Online" : "You're Offline"}
                </p>
                <p className="text-xs text-muted">
                  {isOnline ? "Ready to accept rides" : "Not accepting rides"}
                </p>
              </div>
            </div>
            <Switch
              checked={isOnline}
              onCheckedChange={setIsOnline}
              className="data-[state=checked]:bg-primary"
            />
          </div>
        </Card>
      </div>

      <div className="flex-1 p-6 space-y-6">
        {/* Earnings Stats */}
        <div className="grid grid-cols-2 gap-4">
          <motion.div whileHover={{ scale: 1.02 }}>
            <Card className="p-5 bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
              <div className="flex items-start justify-between mb-2">
                <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-secondary" />
                </div>
                <Badge variant="secondary" className="bg-success/10 text-success border-0">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  +12%
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-1">Today's Earnings</p>
              <p className="text-2xl text-secondary">₹1,275.00</p>
            </Card>
          </motion.div>

          <motion.div whileHover={{ scale: 1.02 }}>
            <Card className="p-5 bg-gradient-to-br from-success/10 to-success/5 border-success/20">
              <div className="flex items-start justify-between mb-2">
                <div className="w-10 h-10 bg-success rounded-xl flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-white" />
                </div>
                <Badge variant="secondary" className="bg-primary/10 text-primary border-0">
                  Active
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-1">Trips Completed</p>
              <p className="text-2xl text-secondary">8 trips</p>
            </Card>
          </motion.div>
        </div>

        {/* Weekly Summary */}
        <Card className="p-5">
          <h3 className="text-lg text-secondary mb-4">This Week</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-primary/5 rounded-xl">
              <div className="flex items-center justify-center gap-1 mb-1">
                <MapPin className="w-4 h-4 text-primary" />
                <p className="text-2xl text-secondary">42</p>
              </div>
              <p className="text-xs text-muted-foreground">Trips</p>
            </div>
            <div className="text-center p-3 bg-success/5 rounded-xl">
              <div className="flex items-center justify-center gap-1 mb-1">
                <DollarSign className="w-4 h-4 text-success" />
                <p className="text-2xl text-secondary">₹6,850</p>
              </div>
              <p className="text-xs text-muted-foreground">Earned</p>
            </div>
            <div className="text-center p-3 bg-primary/5 rounded-xl">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Star className="w-4 h-4 text-primary fill-primary" />
                <p className="text-2xl text-secondary">4.9</p>
              </div>
              <p className="text-xs text-muted-foreground">Rating</p>
            </div>
          </div>
        </Card>

        {/* Recent Trips */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-lg text-secondary">Today's Trips</h3>
            <Button variant="ghost" size="sm" className="text-primary hover:text-accent">
              View All
            </Button>
          </div>

          <div className="space-y-2">
            {todayTrips.map((trip, index) => (
              <motion.div
                key={trip.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-4 hover:bg-primary/5 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-secondary truncate">
                        {trip.from} → {trip.to}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        {trip.time}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-success">
                      <DollarSign className="w-4 h-4" />
                      <span className="text-base">₹{trip.fare}</span>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Bonus Opportunity */}
        <motion.div whileHover={{ scale: 1.01 }}>
          <Card className="p-5 bg-gradient-to-r from-primary/20 via-accent/20 to-primary/20 border-primary/30">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                <Gift className="w-6 h-6 text-secondary" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-secondary mb-1">Complete 2 more trips</p>
                <p className="text-xs text-muted-foreground">
                  to unlock ₹500 bonus today!
                </p>
              </div>
              <Button
                size="sm"
                onClick={() => setShowBonusDetails(true)}
                className="bg-primary hover:bg-accent text-secondary rounded-lg"
              >
                Details
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* Simulate New Ride Request */}
        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Button
            onClick={onNewRide}
            className="w-full h-12 bg-success hover:bg-success/90 text-white rounded-xl shadow-lg"
          >
            Simulate New Ride Request
          </Button>
        </motion.div>
      </div>

      {/* Bonus Details Dialog */}
      <Dialog open={showBonusDetails} onOpenChange={setShowBonusDetails}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                <Gift className="w-5 h-5 text-secondary" />
              </div>
              Daily Bonus Challenge
            </DialogTitle>
            <DialogDescription className="pt-4 space-y-4">
              <div>
                <p className="text-foreground mb-2">Complete your daily target to earn bonus rewards!</p>
                
                <div className="space-y-3 mt-4">
                  <div className="p-3 bg-success/5 border border-success/20 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-secondary">Current Progress</span>
                      <span className="text-sm text-success">8 / 10 trips</span>
                    </div>
                    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: "80%" }}
                        transition={{ duration: 1, ease: "easeOut" }}
                        className="h-full bg-gradient-to-r from-primary to-accent"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <span className="text-sm text-muted-foreground">Base Earnings (Today)</span>
                      <span className="text-sm text-secondary">₹1,275</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                      <span className="text-sm text-primary">Daily Bonus (10 trips)</span>
                      <span className="text-sm text-primary">+₹500</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-success/10 border border-success/20 rounded-lg">
                      <span className="text-sm text-secondary">Potential Total</span>
                      <span className="text-base text-success">₹1,775</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground mt-4">
                  Complete 2 more trips before midnight to unlock this bonus!
                </p>
              </div>
            </DialogDescription>
          </DialogHeader>
          <div className="pt-2">
            <Button
              onClick={() => setShowBonusDetails(false)}
              className="w-full h-12 bg-primary hover:bg-accent text-secondary rounded-xl"
            >
              Let's Go!
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
