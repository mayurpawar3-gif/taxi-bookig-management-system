import { motion, AnimatePresence } from "motion/react";
import {
  LayoutDashboard,
  Users,
  Car,
  Package,
  CreditCard,
  BarChart3,
  Settings,
  MapPin,
  TrendingUp,
  AlertCircle,
  DollarSign,
  Search,
  Trash2,
  Eye,
  EyeOff,
  User,
  LogOut,
  X,
  Download,
  Filter,
  ChevronDown,
  FileText,
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  Navigation,
  UserPlus,
} from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { useState } from "react";
import { useAppContext } from "../contexts/AppContext";

type Section =
  | "Dashboard"
  | "Users"
  | "Drivers"
  | "Bookings"
  | "Payments"
  | "Reports"
  | "Settings";

interface Notification {
  id: number;
  type: "success" | "alert" | "info";
  message: string;
  time: string;
  read: boolean;
  details: string;
}

interface Message {
  id: number;
  name: string;
  message: string;
  time: string;
  unread: boolean;
  fullMessage: string;
}

interface User {
  id: number;
  name: string;
  email: string;
  status: "Active" | "Inactive";
  rides: number;
}

interface Driver {
  id: number;
  name: string;
  vehicle: string;
  rating: number;
  trips: number;
  status: "Online" | "Offline" | "Busy";
}

interface Booking {
  id: string;
  passenger: string;
  from: string;
  to: string;
  fare: string;
  status: "Completed" | "Ongoing" | "Scheduled" | "Cancelled";
  date: string;
}

interface Payment {
  id: string;
  user: string;
  amount: string;
  method: string;
  date: string;
  status: "Completed" | "Pending" | "Failed";
}

interface OngoingRide {
  id: string;
  passenger: string;
  driver: string;
  from: string;
  to: string;
  fare: string;
  status: string;
  progress: number;
}

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard" as Section },
  { icon: Users, label: "Users" as Section },
  { icon: Car, label: "Drivers" as Section },
  { icon: Package, label: "Bookings" as Section },
  { icon: CreditCard, label: "Payments" as Section },
  { icon: BarChart3, label: "Reports" as Section },
  { icon: Settings, label: "Settings" as Section },
];

const statsCards = [
  {
    title: "Total Rides",
    value: "12,543",
    change: "+12.5%",
    icon: Package,
    color: "text-primary",
    bg: "bg-primary/10",
  },
  {
    title: "Active Drivers",
    value: "2,847",
    change: "+8.2%",
    icon: Car,
    color: "text-success",
    bg: "bg-success/10",
  },
  {
    title: "Revenue",
    value: "₹45,89,200",
    change: "+18.4%",
    icon: DollarSign,
    color: "text-primary",
    bg: "bg-primary/10",
  },
  {
    title: "Complaints",
    value: "24",
    change: "-5.1%",
    icon: AlertCircle,
    color: "text-destructive",
    bg: "bg-destructive/10",
  },
];

const initialNotifications: Notification[] = [
  { id: 1, type: "success", message: "New driver Rajesh Kumar registered", time: "2 min ago", read: false, details: "Driver Rajesh Kumar has successfully completed registration with vehicle MH 02 BX 5678. All documents verified. Driver is now active and ready to accept rides." },
  { id: 2, type: "alert", message: "Payment dispute from booking #B10234", time: "15 min ago", read: false, details: "Customer Arjun Sharma has raised a payment dispute for booking #B10234. Amount: ₹340. Reason: Driver took longer route. Action required within 24 hours." },
  { id: 3, type: "info", message: "System maintenance scheduled for tonight", time: "1 hour ago", read: false, details: "Scheduled system maintenance tonight from 11 PM to 2 AM. Services will be temporarily unavailable. All users have been notified via email and SMS." },
  { id: 4, type: "success", message: "Daily revenue target achieved", time: "2 hours ago", read: true, details: "Congratulations! Today's revenue target of ₹5,00,000 has been achieved at 6 PM. Total rides: 234. Total revenue: ₹5,45,000." },
  { id: 5, type: "info", message: "New feature request from drivers", time: "3 hours ago", read: true, details: "Multiple drivers have requested a navigation feature integration. 45 drivers have voted for this feature. Consider for next sprint planning." },
];

const initialMessages: Message[] = [
  { id: 1, name: "Arjun Sharma", message: "Issue with payment refund", time: "5 min ago", unread: true, fullMessage: "Hello Admin, I completed a ride 2 days ago (Booking #B10234) but was charged ₹340 instead of the agreed ₹280. The driver took a longer route without my consent. I've been waiting for a refund for 48 hours. Please help resolve this urgently." },
  { id: 2, name: "Priya Patel", message: "Great service, thank you!", time: "1 hour ago", unread: false, fullMessage: "I wanted to thank you for the excellent service. My driver Rajesh was very professional and courteous. The app is easy to use and the pricing is transparent. Keep up the good work!" },
  { id: 3, name: "Driver Support", message: "Need help with app", time: "2 hours ago", unread: true, fullMessage: "Several drivers are reporting issues with the GPS navigation feature. The app is not showing the correct route to pickup locations. This is affecting their ability to reach customers on time. Please investigate and fix as soon as possible." },
  { id: 4, name: "Rohan Mehta", message: "Booking cancellation inquiry", time: "3 hours ago", unread: false, fullMessage: "I had to cancel my booking #B10236 due to an emergency. Will I be charged a cancellation fee? The booking was cancelled 30 minutes before the scheduled pickup time." },
  { id: 5, name: "Ananya Singh", message: "Driver rating concern", time: "5 hours ago", unread: false, fullMessage: "I accidentally gave my last driver a 3-star rating when I meant to give 5 stars. Is there a way to change the rating? The driver was excellent and doesn't deserve a low rating." },
];

const ongoingRidesData: OngoingRide[] = [
  { id: "#R10541", passenger: "Arjun Sharma", driver: "Rajesh Kumar", from: "Bandra Station", to: "Mumbai Airport", fare: "₹450", status: "Enroute to pickup", progress: 30 },
  { id: "#R10542", passenger: "Priya Patel", driver: "Amit Verma", from: "Worli", to: "Powai", fare: "₹320", status: "Passenger onboard", progress: 65 },
  { id: "#R10543", passenger: "Rohan Mehta", driver: "Suresh Patil", from: "Andheri", to: "Colaba", fare: "₹380", status: "Arriving at pickup", progress: 15 },
  { id: "#R10544", passenger: "Ananya Singh", driver: "Karan Joshi", from: "Dadar", to: "Marine Drive", fare: "₹220", status: "Passenger onboard", progress: 80 },
  { id: "#R10545", passenger: "Vikram Desai", driver: "Rahul Shah", from: "BKC", to: "Gateway of India", fare: "₹290", status: "Enroute to pickup", progress: 45 },
];

export function AdminDashboard({ onNavigateToUserSignup, onNavigateToDriverSignup }: { onNavigateToUserSignup?: () => void; onNavigateToDriverSignup?: () => void }) {
  const [activeSection, setActiveSection] = useState<Section>("Dashboard");
  const [showProfile, setShowProfile] = useState(false);
  
  // Notification and Message state
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [showAllNotifications, setShowAllNotifications] = useState(false);
  const [showAllMessages, setShowAllMessages] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  
  // Report modal state
  const [showReportInfo, setShowReportInfo] = useState(false);
  const [selectedReportType, setSelectedReportType] = useState("");
  
  // Settings modal state
  const [showSettingInfo, setShowSettingInfo] = useState(false);
  const [selectedSetting, setSelectedSetting] = useState("");
  
  // Ongoing rides modal
  const [showOngoingRides, setShowOngoingRides] = useState(false);

  const markNotificationAsRead = (id: number) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markMessageAsRead = (id: number) => {
    setMessages(messages.map(m => m.id === id ? { ...m, unread: false } : m));
  };

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;
  const unreadMessagesCount = messages.filter(m => m.unread).length;

  const renderSectionContent = () => {
    switch (activeSection) {
      case "Dashboard":
        return (
          <DashboardContent 
            onViewOngoingRides={() => setShowOngoingRides(true)}
            onNavigateToUserSignup={onNavigateToUserSignup}
          />
        );
      case "Users":
        return <UsersContent onNavigateToUserSignup={onNavigateToUserSignup} />;
      case "Drivers":
        return <DriversContent onNavigateToDriverSignup={onNavigateToDriverSignup} />;
      case "Bookings":
        return <BookingsContent />;
      case "Payments":
        return <PaymentsContent />;
      case "Reports":
        return (
          <ReportsContent 
            onShowReportInfo={(reportType) => {
              setSelectedReportType(reportType);
              setShowReportInfo(true);
            }}
          />
        );
      case "Settings":
        return (
          <SettingsContent 
            onShowSettingInfo={(setting) => {
              setSelectedSetting(setting);
              setShowSettingInfo(true);
            }}
          />
        );
      default:
        return (
          <DashboardContent 
            onViewOngoingRides={() => setShowOngoingRides(true)}
            onNavigateToUserSignup={onNavigateToUserSignup}
          />
        );
    }
  };

  return (
    <div className="h-full flex bg-white">
      {/* Sidebar */}
      <div className="w-64 bg-secondary flex-shrink-0 flex flex-col">
        {/* Sidebar Header */}
        <div className="p-6 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
              <Car className="w-6 h-6 text-secondary" />
            </div>
            <div>
              <h2 className="text-white">RideNow India</h2>
              <p className="text-xs text-muted">Admin Panel</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 p-4 space-y-1 overflow-auto">
          {navItems.map((item) => (
            <motion.button
              key={item.label}
              onClick={() => setActiveSection(item.label)}
              whileHover={{ x: 4, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all relative group overflow-hidden ${
                activeSection === item.label
                  ? "bg-primary text-secondary shadow-lg shadow-primary/30"
                  : "text-white hover:bg-sidebar-accent"
              }`}
            >
              <item.icon className="w-5 h-5 relative z-10" />
              <span className="text-sm relative z-10">{item.label}</span>
              
              {activeSection === item.label && (
                <motion.div
                  layoutId="activeNavBg"
                  className="absolute inset-0 bg-primary rounded-xl"
                  transition={{ type: "spring", duration: 0.6, bounce: 0.2 }}
                />
              )}
            </motion.button>
          ))}
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10 border-2 border-primary">
              <AvatarFallback className="bg-primary text-secondary">
                AD
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="text-sm text-white">Admin User</p>
              <p className="text-xs text-muted">Super Admin</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Navigation Bar - Simplified (no notification/message icons) */}
        <div className="p-6 border-b bg-white relative z-20">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl text-secondary mb-1">{activeSection} Overview</h1>
              <p className="text-sm text-muted-foreground">
                Welcome back! Here's what's happening today.
              </p>
            </div>

            {/* Top Bar Actions - Only Profile */}
            <div className="flex items-center gap-3">
              {/* Profile */}
              <div className="relative">
                <motion.button
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setShowProfile(!showProfile)}
                  className="flex items-center gap-2 px-3 py-2 bg-input-background hover:bg-primary/10 rounded-xl transition-all group"
                >
                  <Avatar className="w-8 h-8 border-2 border-primary">
                    <AvatarFallback className="bg-primary text-secondary text-xs">
                      AD
                    </AvatarFallback>
                  </Avatar>
                  <ChevronDown className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                </motion.button>

                {/* Profile Dropdown */}
                <AnimatePresence>
                  {showProfile && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                      className="absolute right-0 top-12 w-64 bg-white rounded-xl shadow-2xl border overflow-hidden z-50"
                    >
                      <div className="p-4 border-b bg-gradient-to-r from-primary/5 to-accent/5">
                        <div className="flex items-center gap-3">
                          <Avatar className="w-12 h-12 border-2 border-primary">
                            <AvatarFallback className="bg-primary text-secondary">
                              AD
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm text-secondary">Admin User</p>
                            <p className="text-xs text-muted-foreground">admin@ridenow.in</p>
                          </div>
                        </div>
                      </div>
                      <div className="p-2">
                        <motion.button
                          whileHover={{ backgroundColor: "rgba(255, 180, 0, 0.1)", x: 4 }}
                          whileTap={{ scale: 0.98 }}
                          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-secondary"
                        >
                          <User className="w-4 h-4" />
                          View Profile
                        </motion.button>
                        <motion.button
                          whileHover={{ backgroundColor: "rgba(255, 77, 77, 0.1)", x: 4 }}
                          whileTap={{ scale: 0.98 }}
                          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-destructive"
                        >
                          <LogOut className="w-4 h-4" />
                          Logout
                        </motion.button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>

        {/* Section Content with Animation */}
        <div className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full overflow-auto"
            >
              {renderSectionContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* All Notifications Modal */}
      <Dialog open={showAllNotifications} onOpenChange={setShowAllNotifications}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>All Notifications</DialogTitle>
            <DialogDescription>
              View and manage all system notifications
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-96 overflow-auto">
            {notifications.map((notif) => (
              <motion.div
                key={notif.id}
                whileHover={{ backgroundColor: "rgba(255, 180, 0, 0.05)" }}
                onClick={() => {
                  setSelectedNotification(notif);
                  markNotificationAsRead(notif.id);
                }}
                className="p-4 border rounded-lg cursor-pointer relative"
              >
                <div className="flex gap-3">
                  <div className={`w-3 h-3 rounded-full mt-1.5 flex-shrink-0 ${
                    notif.type === "success" ? "bg-success" :
                    notif.type === "alert" ? "bg-destructive" : "bg-primary"
                  }`} />
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <p className="text-sm text-secondary">{notif.message}</p>
                      {!notif.read && (
                        <Badge className="bg-primary/10 text-primary border-0 ml-2">New</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{notif.time}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Notification Detail Modal */}
      <Dialog open={!!selectedNotification} onOpenChange={() => setSelectedNotification(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${
                selectedNotification?.type === "success" ? "bg-success" :
                selectedNotification?.type === "alert" ? "bg-destructive" : "bg-primary"
              }`} />
              Notification Details
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-secondary mb-2">{selectedNotification?.message}</p>
              <p className="text-xs text-muted-foreground mb-4">{selectedNotification?.time}</p>
              <div className="p-4 bg-muted/30 rounded-lg">
                <p className="text-sm text-foreground">{selectedNotification?.details}</p>
              </div>
            </div>
            <Button onClick={() => setSelectedNotification(null)} className="w-full bg-primary hover:bg-accent text-secondary">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* All Messages Modal */}
      <Dialog open={showAllMessages} onOpenChange={setShowAllMessages}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>All Messages</DialogTitle>
            <DialogDescription>
              View and manage all user messages
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-96 overflow-auto">
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                whileHover={{ backgroundColor: "rgba(255, 180, 0, 0.05)" }}
                onClick={() => {
                  setSelectedMessage(msg);
                  markMessageAsRead(msg.id);
                }}
                className="p-4 border rounded-lg cursor-pointer"
              >
                <div className="flex gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="bg-primary/10 text-primary text-xs">
                      {msg.name.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm text-secondary truncate">{msg.name}</p>
                      {msg.unread && (
                        <Badge className="bg-primary/10 text-primary border-0 ml-2">New</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{msg.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">{msg.time}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Message Detail Modal */}
      <Dialog open={!!selectedMessage} onOpenChange={() => setSelectedMessage(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-primary/10 text-primary">
                  {selectedMessage?.name.split(" ").map(n => n[0]).join("")}
                </AvatarFallback>
              </Avatar>
              {selectedMessage?.name}
            </DialogTitle>
            <DialogDescription>
              {selectedMessage?.time}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-muted/30 rounded-lg">
              <p className="text-sm text-foreground">{selectedMessage?.fullMessage}</p>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => setSelectedMessage(null)} variant="outline" className="flex-1">
                Close
              </Button>
              <Button className="flex-1 bg-primary hover:bg-accent text-secondary">
                Reply
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Ongoing Rides Modal */}
      <Dialog open={showOngoingRides} onOpenChange={setShowOngoingRides}>
        <DialogContent className="sm:max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Ongoing Rides</DialogTitle>
            <DialogDescription>
              Real-time view of all active rides
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-96 overflow-auto">
            {ongoingRidesData.map((ride) => (
              <Card key={ride.id} className="p-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-secondary">{ride.id}</p>
                      <p className="text-xs text-muted-foreground">Driver: {ride.driver}</p>
                    </div>
                    <Badge className={
                      ride.progress < 30 ? "bg-primary/10 text-primary" :
                      ride.progress < 70 ? "bg-success/10 text-success" :
                      "bg-accent/10 text-secondary"
                    }>
                      {ride.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-primary" />
                    <span className="text-muted-foreground">{ride.from}</span>
                    <Navigation className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{ride.to}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Passenger: {ride.passenger}</span>
                    <span className="text-success">{ride.fare}</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${ride.progress}%` }}
                      transition={{ duration: 0.5 }}
                      className="bg-gradient-to-r from-primary to-accent h-full rounded-full"
                    />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Report Info Modal */}
      <Dialog open={showReportInfo} onOpenChange={setShowReportInfo}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              {selectedReportType}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <ReportInfoContent reportType={selectedReportType} />
            <div className="flex gap-2">
              <Button onClick={() => setShowReportInfo(false)} variant="outline" className="flex-1">
                Cancel
              </Button>
              <Button className="flex-1 bg-primary hover:bg-accent text-secondary gap-2">
                <Download className="w-4 h-4" />
                Download
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Setting Info Modal */}
      <Dialog open={showSettingInfo} onOpenChange={setShowSettingInfo}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-primary" />
              {selectedSetting}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <SettingInfoContent setting={selectedSetting} />
            <Button onClick={() => setShowSettingInfo(false)} className="w-full bg-primary hover:bg-accent text-secondary">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Notification & Message Access Buttons in Sidebar */}
      <div className="fixed bottom-20 left-4 space-y-2 z-30">
        <motion.button
          whileHover={{ scale: 1.1, x: 5 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowAllNotifications(true)}
          className="relative w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-primary/30"
        >
          <AlertCircle className="w-6 h-6 text-secondary" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-white text-xs rounded-full flex items-center justify-center">
              {unreadNotificationsCount}
            </span>
          )}
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.1, x: 5 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowAllMessages(true)}
          className="relative w-12 h-12 bg-success rounded-xl flex items-center justify-center shadow-lg shadow-success/30"
        >
          <User className="w-6 h-6 text-white" />
          {unreadMessagesCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-secondary text-xs rounded-full flex items-center justify-center">
              {unreadMessagesCount}
            </span>
          )}
        </motion.button>
      </div>
    </div>
  );
}

// Dashboard Section Content
function DashboardContent({ onViewOngoingRides, onNavigateToUserSignup }: { onViewOngoingRides: () => void; onNavigateToUserSignup?: () => void }) {
  return (
    <div className="p-6 space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statsCards.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Card className="p-5 hover:shadow-lg hover:shadow-primary/10 transition-all cursor-pointer group relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/0 via-primary/5 to-accent/0 opacity-0 group-hover:opacity-100 transition-opacity" />
              
              <div className="flex items-start justify-between mb-3 relative z-10">
                <div className={`w-12 h-12 ${stat.bg} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <Badge
                  variant="secondary"
                  className={`${
                    stat.change.startsWith("+")
                      ? "bg-success/10 text-success"
                      : "bg-destructive/10 text-destructive"
                  } border-0`}
                >
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {stat.change}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-1 relative z-10">{stat.title}</p>
              <p className="text-2xl text-secondary relative z-10">{stat.value}</p>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Rides Map */}
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg text-secondary">Active Rides - Mumbai</h3>
            <Button onClick={onViewOngoingRides} size="sm" className="bg-primary hover:bg-accent text-secondary gap-2">
              <Eye className="w-4 h-4" />
              View All
            </Button>
          </div>
          <div className="relative h-64 bg-gradient-to-br from-muted/20 to-muted/40 rounded-xl overflow-hidden">
            <div className="absolute inset-0" style={{
              backgroundImage: "linear-gradient(rgba(0,0,0,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.05) 1px, transparent 1px)",
              backgroundSize: "20px 20px"
            }} />
            
            {ongoingRidesData.slice(0, 5).map((ride, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className="absolute"
                style={{ 
                  top: `${20 + i * 15}%`, 
                  left: `${25 + (i % 3) * 20}%` 
                }}
              >
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
                  className="w-4 h-4 bg-primary rounded-full shadow-lg shadow-primary/50"
                />
              </motion.div>
            ))}
            
            <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Active Now:</span>
                <span className="text-secondary">{ongoingRidesData.length} rides</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Recent Users with Search and Filters */}
        <RecentUsersTable onNavigateToUserSignup={onNavigateToUserSignup} />
      </div>
    </div>
  );
}

// Recent Users Table Component
function RecentUsersTable({ onNavigateToUserSignup }: { onNavigateToUserSignup?: () => void }) {
  const { users, deleteUser } = useAppContext();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [hiddenColumns, setHiddenColumns] = useState<string[]>([]);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === "all" || user.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const toggleColumnVisibility = (column: string) => {
    setHiddenColumns(prev =>
      prev.includes(column) ? prev.filter(c => c !== column) : [...prev, column]
    );
  };

  return (
    <Card className="p-5">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg text-secondary">Recent Users</h3>
          <div className="flex gap-2">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-32 h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 h-9 bg-input-background"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => toggleColumnVisibility("rides")}
            className="h-8"
          >
            {hiddenColumns.includes("rides") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
            Rides
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => toggleColumnVisibility("status")}
            className="h-8"
          >
            {hiddenColumns.includes("status") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
            Status
          </Button>
        </div>

        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                {!hiddenColumns.includes("rides") && <TableHead>Rides</TableHead>}
                {!hiddenColumns.includes("status") && <TableHead>Status</TableHead>}
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div>
                      <p className="text-sm text-secondary">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                  </TableCell>
                  {!hiddenColumns.includes("rides") && (
                    <TableCell className="text-sm">{user.rides}</TableCell>
                  )}
                  {!hiddenColumns.includes("status") && (
                    <TableCell>
                      <Badge className={user.status === "Active" ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"}>
                        {user.status}
                      </Badge>
                    </TableCell>
                  )}
                  <TableCell className="text-right">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteUser(user.id)}
                      className="h-8 text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </Card>
  );
}

// Users Content Component
function UsersContent({ onNavigateToUserSignup }: { onNavigateToUserSignup?: () => void }) {
  const { users, deleteUser: removeUser } = useAppContext();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [hiddenColumns, setHiddenColumns] = useState<string[]>([]);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === "all" || user.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const toggleColumnVisibility = (column: string) => {
    setHiddenColumns(prev =>
      prev.includes(column) ? prev.filter(c => c !== column) : [...prev, column]
    );
  };

  const deleteUser = (id: number) => {
    if (confirm("Are you sure you want to delete this user?")) {
      removeUser(id);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl text-secondary">User Management</h2>
          <p className="text-sm text-muted-foreground">Manage all registered users</p>
        </div>
        <Button onClick={onNavigateToUserSignup} className="bg-primary hover:bg-accent text-secondary gap-2">
          <UserPlus className="w-4 h-4" />
          Add New User
        </Button>
      </div>

      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-input-background"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-wrap gap-2">
            <span className="text-sm text-muted-foreground">Show/Hide Columns:</span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("rides")}
            >
              {hiddenColumns.includes("rides") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Total Rides
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("status")}
            >
              {hiddenColumns.includes("status") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Status
            </Button>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  {!hiddenColumns.includes("rides") && <TableHead>Total Rides</TableHead>}
                  {!hiddenColumns.includes("status") && <TableHead>Status</TableHead>}
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="text-sm text-muted-foreground">#{user.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">
                            {user.name.split(" ").map(n => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm text-secondary">{user.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{user.email}</TableCell>
                    {!hiddenColumns.includes("rides") && (
                      <TableCell className="text-sm">{user.rides}</TableCell>
                    )}
                    {!hiddenColumns.includes("status") && (
                      <TableCell>
                        <Badge className={user.status === "Active" ? "bg-success/10 text-success border-0" : "bg-muted text-muted-foreground border-0"}>
                          {user.status}
                        </Badge>
                      </TableCell>
                    )}
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => deleteUser(user.id)}
                        className="text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredUsers.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No users found matching your criteria
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

// Drivers Content Component
function DriversContent({ onNavigateToDriverSignup }: { onNavigateToDriverSignup?: () => void }) {
  const { drivers, deleteDriver: removeDriver } = useAppContext();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [hiddenColumns, setHiddenColumns] = useState<string[]>([]);

  const filteredDrivers = drivers.filter(driver => {
    const matchesSearch = driver.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         driver.vehicle.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === "all" || driver.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const toggleColumnVisibility = (column: string) => {
    setHiddenColumns(prev =>
      prev.includes(column) ? prev.filter(c => c !== column) : [...prev, column]
    );
  };

  const deleteDriver = (id: number) => {
    if (confirm("Are you sure you want to delete this driver?")) {
      removeDriver(id);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl text-secondary">Driver Management</h2>
          <p className="text-sm text-muted-foreground">Manage all registered drivers</p>
        </div>
        <Button onClick={onNavigateToDriverSignup} className="bg-primary hover:bg-accent text-secondary gap-2">
          <Car className="w-4 h-4" />
          Add New Driver
        </Button>
      </div>

      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or vehicle..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-input-background"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Online">Online</SelectItem>
                <SelectItem value="Offline">Offline</SelectItem>
                <SelectItem value="Busy">Busy</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-wrap gap-2">
            <span className="text-sm text-muted-foreground">Show/Hide Columns:</span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("trips")}
            >
              {hiddenColumns.includes("trips") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Total Trips
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("vehicle")}
            >
              {hiddenColumns.includes("vehicle") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Vehicle
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("rating")}
            >
              {hiddenColumns.includes("rating") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Rating
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("status")}
            >
              {hiddenColumns.includes("status") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Status
            </Button>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  {!hiddenColumns.includes("vehicle") && <TableHead>Vehicle</TableHead>}
                  {!hiddenColumns.includes("rating") && <TableHead>Rating</TableHead>}
                  {!hiddenColumns.includes("trips") && <TableHead>Total Trips</TableHead>}
                  {!hiddenColumns.includes("status") && <TableHead>Status</TableHead>}
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDrivers.map((driver) => (
                  <TableRow key={driver.id}>
                    <TableCell className="text-sm text-muted-foreground">#{driver.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">
                            {driver.name.split(" ").map(n => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm text-secondary">{driver.name}</span>
                      </div>
                    </TableCell>
                    {!hiddenColumns.includes("vehicle") && (
                      <TableCell className="text-sm text-muted-foreground">{driver.vehicle}</TableCell>
                    )}
                    {!hiddenColumns.includes("rating") && (
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <span className="text-sm text-primary">★</span>
                          <span className="text-sm">{driver.rating}</span>
                        </div>
                      </TableCell>
                    )}
                    {!hiddenColumns.includes("trips") && (
                      <TableCell className="text-sm">{driver.trips}</TableCell>
                    )}
                    {!hiddenColumns.includes("status") && (
                      <TableCell>
                        <Badge className={
                          driver.status === "Online" ? "bg-success/10 text-success border-0" :
                          driver.status === "Busy" ? "bg-primary/10 text-primary border-0" :
                          "bg-muted text-muted-foreground border-0"
                        }>
                          {driver.status}
                        </Badge>
                      </TableCell>
                    )}
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => deleteDriver(driver.id)}
                        className="text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredDrivers.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No drivers found matching your criteria
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

// Bookings Content Component
function BookingsContent() {
  const [bookings, setBookings] = useState<Booking[]>([
    { id: "#B10234", passenger: "Arjun Sharma", from: "Bandra Kurla Complex", to: "Gateway of India", fare: "₹340", status: "Completed", date: "2025-11-03" },
    { id: "#B10235", passenger: "Priya Patel", from: "Andheri East", to: "Marine Drive", fare: "₹280", status: "Ongoing", date: "2025-11-04" },
    { id: "#B10236", passenger: "Rohan Mehta", from: "Powai", to: "Colaba Causeway", fare: "₹450", status: "Scheduled", date: "2025-11-04" },
    { id: "#B10237", passenger: "Ananya Singh", from: "Dadar West", to: "Juhu Beach", fare: "₹220", status: "Cancelled", date: "2025-11-02" },
    { id: "#B10238", passenger: "Vikram Desai", from: "BKC", to: "CST", fare: "₹310", status: "Completed", date: "2025-11-03" },
  ]);
  
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDate, setFilterDate] = useState("");
  const [hiddenColumns, setHiddenColumns] = useState<string[]>([]);

  const filteredBookings = bookings.filter(booking => {
    const matchesSearch = booking.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         booking.passenger.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDate = !filterDate || booking.date === filterDate;
    return matchesSearch && matchesDate;
  });

  const toggleColumnVisibility = (column: string) => {
    setHiddenColumns(prev =>
      prev.includes(column) ? prev.filter(c => c !== column) : [...prev, column]
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl text-secondary">Booking Management</h2>
          <p className="text-sm text-muted-foreground">View and manage all bookings</p>
        </div>
      </div>

      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by booking ID or passenger..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-input-background"
              />
            </div>
            <div className="relative w-full md:w-48">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="date"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <span className="text-sm text-muted-foreground">Show/Hide Columns:</span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("passenger")}
            >
              {hiddenColumns.includes("passenger") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Passenger
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("from")}
            >
              {hiddenColumns.includes("from") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              From
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("to")}
            >
              {hiddenColumns.includes("to") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              To
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("fare")}
            >
              {hiddenColumns.includes("fare") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Fare
            </Button>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Booking ID</TableHead>
                  {!hiddenColumns.includes("passenger") && <TableHead>Passenger</TableHead>}
                  {!hiddenColumns.includes("from") && <TableHead>From</TableHead>}
                  {!hiddenColumns.includes("to") && <TableHead>To</TableHead>}
                  {!hiddenColumns.includes("fare") && <TableHead>Fare</TableHead>}
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBookings.map((booking) => (
                  <TableRow key={booking.id}>
                    <TableCell className="text-sm text-primary">{booking.id}</TableCell>
                    {!hiddenColumns.includes("passenger") && (
                      <TableCell className="text-sm text-secondary">{booking.passenger}</TableCell>
                    )}
                    {!hiddenColumns.includes("from") && (
                      <TableCell className="text-sm text-muted-foreground">{booking.from}</TableCell>
                    )}
                    {!hiddenColumns.includes("to") && (
                      <TableCell className="text-sm text-muted-foreground">{booking.to}</TableCell>
                    )}
                    {!hiddenColumns.includes("fare") && (
                      <TableCell className="text-sm text-success">{booking.fare}</TableCell>
                    )}
                    <TableCell className="text-sm text-muted-foreground">{booking.date}</TableCell>
                    <TableCell>
                      <Badge className={
                        booking.status === "Completed" ? "bg-success/10 text-success border-0" :
                        booking.status === "Ongoing" ? "bg-primary/10 text-primary border-0" :
                        booking.status === "Scheduled" ? "bg-accent/10 text-secondary border-0" :
                        "bg-destructive/10 text-destructive border-0"
                      }>
                        {booking.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredBookings.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No bookings found matching your criteria
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

// Payments Content Component
function PaymentsContent() {
  const [payments, setPayments] = useState<Payment[]>([
    { id: "#P5678", user: "Arjun Sharma", amount: "₹340", method: "UPI", date: "Oct 8, 2025", status: "Completed" },
    { id: "#P5679", user: "Priya Patel", amount: "₹280", method: "Paytm", date: "Oct 8, 2025", status: "Pending" },
    { id: "#P5680", user: "Rohan Mehta", amount: "₹450", method: "Cash", date: "Oct 7, 2025", status: "Completed" },
    { id: "#P5681", user: "Ananya Singh", amount: "₹220", method: "Card", date: "Oct 7, 2025", status: "Failed" },
    { id: "#P5682", user: "Vikram Desai", amount: "₹310", method: "PhonePe", date: "Oct 6, 2025", status: "Completed" },
  ]);
  
  const [searchTerm, setSearchTerm] = useState("");
  const [hiddenColumns, setHiddenColumns] = useState<string[]>([]);

  const filteredPayments = payments.filter(payment => {
    const matchesSearch = payment.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.user.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const toggleColumnVisibility = (column: string) => {
    setHiddenColumns(prev =>
      prev.includes(column) ? prev.filter(c => c !== column) : [...prev, column]
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl text-secondary">Payment Management</h2>
          <p className="text-sm text-muted-foreground">View and manage all transactions</p>
        </div>
      </div>

      <Card className="p-6">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by transaction ID or passenger name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 bg-input-background"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <span className="text-sm text-muted-foreground">Show/Hide Columns:</span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("passenger")}
            >
              {hiddenColumns.includes("passenger") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Passenger Name
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("fare")}
            >
              {hiddenColumns.includes("fare") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Fare
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("method")}
            >
              {hiddenColumns.includes("method") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Method
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => toggleColumnVisibility("date")}
            >
              {hiddenColumns.includes("date") ? <Eye className="w-3 h-3 mr-1" /> : <EyeOff className="w-3 h-3 mr-1" />}
              Date
            </Button>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Transaction ID</TableHead>
                  {!hiddenColumns.includes("passenger") && <TableHead>Passenger</TableHead>}
                  {!hiddenColumns.includes("fare") && <TableHead>Amount</TableHead>}
                  {!hiddenColumns.includes("method") && <TableHead>Method</TableHead>}
                  {!hiddenColumns.includes("date") && <TableHead>Date</TableHead>}
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPayments.map((payment) => (
                  <TableRow key={payment.id}>
                    <TableCell className="text-sm text-primary">{payment.id}</TableCell>
                    {!hiddenColumns.includes("passenger") && (
                      <TableCell className="text-sm text-secondary">{payment.user}</TableCell>
                    )}
                    {!hiddenColumns.includes("fare") && (
                      <TableCell className="text-sm text-success">{payment.amount}</TableCell>
                    )}
                    {!hiddenColumns.includes("method") && (
                      <TableCell className="text-sm text-muted-foreground">{payment.method}</TableCell>
                    )}
                    {!hiddenColumns.includes("date") && (
                      <TableCell className="text-sm text-muted-foreground">{payment.date}</TableCell>
                    )}
                    <TableCell>
                      <Badge className={
                        payment.status === "Completed" ? "bg-success/10 text-success border-0" :
                        payment.status === "Pending" ? "bg-primary/10 text-primary border-0" :
                        "bg-destructive/10 text-destructive border-0"
                      }>
                        {payment.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredPayments.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No payments found matching your criteria
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

// Reports Content Component
function ReportsContent({ onShowReportInfo }: { onShowReportInfo: (reportType: string) => void }) {
  const reportTemplates = [
    { name: "Daily Revenue Report", icon: DollarSign, color: "text-success", bg: "bg-success/10" },
    { name: "Weekly Bookings Summary", icon: Package, color: "text-primary", bg: "bg-primary/10" },
    { name: "Driver Performance Analysis", icon: Car, color: "text-primary", bg: "bg-primary/10" },
    { name: "User Activity Report", icon: Users, color: "text-success", bg: "bg-success/10" },
    { name: "Payment Transaction Log", icon: CreditCard, color: "text-primary", bg: "bg-primary/10" },
    { name: "Monthly Financial Report", icon: BarChart3, color: "text-success", bg: "bg-success/10" },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl text-secondary">Reports Overview</h2>
          <p className="text-sm text-muted-foreground">Generate and download business reports</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {reportTemplates.map((report, index) => (
          <motion.div
            key={report.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Card className="p-6 hover:shadow-lg hover:shadow-primary/10 transition-all cursor-pointer group">
              <div className="space-y-4">
                <div className={`w-12 h-12 ${report.bg} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <report.icon className={`w-6 h-6 ${report.color}`} />
                </div>
                <div>
                  <h3 className="text-base text-secondary mb-2">{report.name}</h3>
                </div>
                <Button
                  onClick={() => onShowReportInfo(report.name)}
                  className="w-full bg-primary hover:bg-accent text-secondary gap-2"
                >
                  <Download className="w-4 h-4" />
                  Generate Report
                </Button>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// Settings Content Component
function SettingsContent({ onShowSettingInfo }: { onShowSettingInfo: (setting: string) => void }) {
  const systemSettings = [
    { name: "General Settings", description: "App name, logo, and basic configuration", icon: Settings },
    { name: "Payment Settings", description: "Configure payment gateways and methods", icon: CreditCard },
    { name: "Notification Settings", description: "Email, SMS, and push notification preferences", icon: AlertCircle },
    { name: "Map & Location Settings", description: "Google Maps API and location services", icon: MapPin },
    { name: "Pricing Settings", description: "Base fare, per km charges, and surge pricing", icon: DollarSign },
    { name: "Security Settings", description: "Authentication, encryption, and access control", icon: CheckCircle },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl text-secondary">Settings Overview</h2>
          <p className="text-sm text-muted-foreground">Configure system settings</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {systemSettings.map((setting, index) => (
          <motion.div
            key={setting.name}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ x: 4, scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
          >
            <Card
              onClick={() => onShowSettingInfo(setting.name)}
              className="p-5 hover:shadow-lg hover:shadow-primary/10 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                  <setting.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-base text-secondary mb-1">{setting.name}</h3>
                  <p className="text-sm text-muted-foreground">{setting.description}</p>
                </div>
                <ChevronDown className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors -rotate-90" />
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// Report Info Content
function ReportInfoContent({ reportType }: { reportType: string }) {
  const reportInfo: Record<string, { description: string; includes: string[] }> = {
    "Daily Revenue Report": {
      description: "Get comprehensive daily revenue insights including total earnings, completed rides, and payment method breakdowns.",
      includes: [
        "Total revenue for the selected date",
        "Number of completed rides",
        "Breakdown by payment method (UPI, Cash, Card, etc.)",
        "Commission earned",
        "Hour-by-hour revenue chart",
        "Top performing drivers"
      ]
    },
    "Weekly Bookings Summary": {
      description: "View weekly booking trends, patterns, and performance metrics to understand business growth.",
      includes: [
        "Total bookings for the week",
        "Completion vs cancellation rate",
        "Daily booking distribution",
        "Peak hours and days",
        "Customer retention metrics",
        "Average booking value"
      ]
    },
    "Driver Performance Analysis": {
      description: "Analyze driver performance metrics including ratings, earnings, and trip completion rates.",
      includes: [
        "Top 10 performing drivers",
        "Average ratings per driver",
        "Total trips completed",
        "Earnings per driver",
        "Acceptance and cancellation rates",
        "Customer feedback summary"
      ]
    },
    "User Activity Report": {
      description: "Track user engagement, registration trends, and activity patterns across the platform.",
      includes: [
        "New user registrations",
        "Active vs inactive users",
        "Booking frequency per user",
        "User retention rate",
        "Geographic distribution",
        "Peak usage times"
      ]
    },
    "Payment Transaction Log": {
      description: "Detailed log of all payment transactions including successful, pending, and failed payments.",
      includes: [
        "All transactions with status",
        "Payment method breakdown",
        "Failed transaction analysis",
        "Refund requests and status",
        "Commission calculations",
        "Outstanding payments"
      ]
    },
    "Monthly Financial Report": {
      description: "Comprehensive monthly financial overview including revenue, expenses, and profit margins.",
      includes: [
        "Total monthly revenue",
        "Operational costs breakdown",
        "Net profit margin",
        "Month-over-month growth",
        "Driver payouts",
        "Tax calculations"
      ]
    }
  };

  const info = reportInfo[reportType] || { description: "", includes: [] };

  return (
    <div className="space-y-4">
      <p className="text-sm text-foreground">{info.description}</p>
      <div>
        <p className="text-sm text-secondary mb-2">This report includes:</p>
        <ul className="space-y-2">
          {info.includes.map((item, index) => (
            <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
              <CheckCircle className="w-4 h-4 text-success mt-0.5 flex-shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="p-3 bg-primary/5 rounded-lg border border-primary/20">
        <p className="text-xs text-muted-foreground">
          Report will be generated in PDF format and downloaded to your device.
        </p>
      </div>
    </div>
  );
}

// Setting Info Content
function SettingInfoContent({ setting }: { setting: string }) {
  const settingInfo: Record<string, { description: string; options: string[] }> = {
    "General Settings": {
      description: "Configure basic application settings including branding, language, and regional preferences.",
      options: [
        "Application name and logo",
        "Default language and timezone",
        "Currency settings (INR)",
        "Contact information",
        "Terms of service and privacy policy links",
        "App version and update settings"
      ]
    },
    "Payment Settings": {
      description: "Manage payment gateway integrations and configure accepted payment methods.",
      options: [
        "Enable/disable payment methods (UPI, Card, Cash, Wallet)",
        "Payment gateway API configuration",
        "Commission rates and calculations",
        "Automatic payout schedules",
        "Refund policy settings",
        "Payment notification preferences"
      ]
    },
    "Notification Settings": {
      description: "Control how and when notifications are sent to users and drivers.",
      options: [
        "Email notification templates",
        "SMS gateway configuration",
        "Push notification settings",
        "Notification frequency limits",
        "Critical alerts configuration",
        "Opt-in/opt-out management"
      ]
    },
    "Map & Location Settings": {
      description: "Configure map services and location-based features for the application.",
      options: [
        "Google Maps API key",
        "Default map view and zoom level",
        "Geofencing boundaries",
        "Location tracking precision",
        "Offline map support",
        "Route optimization settings"
      ]
    },
    "Pricing Settings": {
      description: "Set and manage fare calculation rules, surge pricing, and promotional offers.",
      options: [
        "Base fare amount",
        "Per kilometer charge",
        "Time-based charges",
        "Surge pricing multipliers",
        "Discount and promo code settings",
        "Cancellation fee rules"
      ]
    },
    "Security Settings": {
      description: "Configure security measures to protect user data and ensure safe transactions.",
      options: [
        "Two-factor authentication",
        "Password complexity requirements",
        "Session timeout duration",
        "Data encryption settings",
        "Access control and permissions",
        "Security audit logs"
      ]
    }
  };

  const info = settingInfo[setting] || { description: "", options: [] };

  return (
    <div className="space-y-4">
      <p className="text-sm text-foreground">{info.description}</p>
      <div>
        <p className="text-sm text-secondary mb-2">Available options:</p>
        <ul className="space-y-2">
          {info.options.map((option, index) => (
            <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
              <Settings className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <span>{option}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="p-3 bg-accent/10 rounded-lg border border-accent/20">
        <p className="text-xs text-muted-foreground">
          Changes to these settings will affect all users. Make sure to test thoroughly before applying.
        </p>
      </div>
    </div>
  );
}
