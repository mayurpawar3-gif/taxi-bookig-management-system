import { motion, AnimatePresence } from "motion/react";
import {
  CreditCard,
  Wallet,
  DollarSign,
  Star,
  MessageSquare,
  CheckCircle,
} from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { useState } from "react";

const paymentMethods = [
  { id: "cash", name: "Cash", icon: DollarSign, badge: "Default" },
  { id: "upi", name: "UPI", icon: Wallet, badge: "PhonePe / GPay" },
  { id: "paytm", name: "Paytm Wallet", icon: Wallet, badge: "₹1,250.50" },
  { id: "card", name: "Credit/Debit Card", icon: CreditCard, badge: "•••• 4242" },
];

export function PassengerPayment({ onComplete }: { onComplete: () => void }) {
  const [selectedPayment, setSelectedPayment] = useState("cash");
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    setSubmitted(true);
    setTimeout(onComplete, 2000);
  };

  return (
    <div className="h-full flex flex-col bg-white overflow-auto">
      <AnimatePresence mode="wait">
        {submitted ? (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1 flex flex-col items-center justify-center p-8 text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", delay: 0.2 }}
              className="w-24 h-24 bg-success rounded-full flex items-center justify-center mb-6 shadow-2xl shadow-success/40"
            >
              <CheckCircle className="w-12 h-12 text-white" />
            </motion.div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-3xl text-secondary mb-3"
            >
              Thank You!
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="text-muted-foreground text-lg"
            >
              Your payment has been processed successfully
            </motion.p>
          </motion.div>
        ) : (
          <motion.div
            key="payment"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex-1 p-6 space-y-6"
          >
            {/* Trip Summary */}
            <Card className="p-5 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
              <h2 className="text-xl text-secondary mb-4">Trip Completed!</h2>
              
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Base Fare</span>
                  <span className="text-secondary">₹180.00</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Distance (12.5 km)</span>
                  <span className="text-secondary">₹75.00</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Service Fee</span>
                  <span className="text-secondary">₹25.00</span>
                </div>
                <div className="border-t border-border/50 pt-3 mt-3">
                  <div className="flex justify-between items-center">
                    <span className="text-lg text-secondary">Total Amount</span>
                    <span className="text-2xl text-primary">₹280.00</span>
                  </div>
                </div>
              </div>
            </Card>

            {/* Driver Info */}
            <Card className="p-4">
              <div className="flex items-center gap-3 mb-4">
                <Avatar className="w-14 h-14 border-2 border-primary">
                  <AvatarFallback className="bg-primary text-secondary">
                    JD
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="text-base text-secondary">Rohan Mehta</p>
                  <p className="text-sm text-muted-foreground">Maruti Ertiga • MH 02 BX 5678</p>
                </div>
              </div>

              {/* Rating */}
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">Rate your experience</p>
                <div className="flex gap-2 justify-center py-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <motion.button
                      key={star}
                      whileHover={{ scale: 1.2 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      className="focus:outline-none"
                    >
                      <Star
                        className={`w-10 h-10 transition-all ${
                          star <= (hoverRating || rating)
                            ? "fill-primary text-primary"
                            : "text-muted"
                        }`}
                      />
                    </motion.button>
                  ))}
                </div>
                {rating > 0 && (
                  <motion.p
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center text-sm text-primary"
                  >
                    {rating === 5 && "Excellent! ⭐"}
                    {rating === 4 && "Great! 😊"}
                    {rating === 3 && "Good 👍"}
                    {rating === 2 && "Fair 😐"}
                    {rating === 1 && "Poor 😞"}
                  </motion.p>
                )}
              </div>

              {/* Feedback */}
              <div className="space-y-2 mt-4">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-muted-foreground" />
                  <label className="text-sm text-muted-foreground">
                    Share your feedback (optional)
                  </label>
                </div>
                <Textarea
                  placeholder="Tell us about your ride..."
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  className="min-h-24 resize-none bg-input-background border-border focus:border-primary rounded-xl"
                />
              </div>
            </Card>

            {/* Payment Method */}
            <div className="space-y-3">
              <h3 className="text-lg text-secondary">Select Payment Method</h3>
              <div className="space-y-2">
                {paymentMethods.map((method) => (
                  <motion.div
                    key={method.id}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <Card
                      onClick={() => setSelectedPayment(method.id)}
                      className={`p-4 cursor-pointer transition-all ${
                        selectedPayment === method.id
                          ? "border-2 border-primary bg-primary/5 shadow-lg shadow-primary/10"
                          : "border-border hover:border-primary/50 hover:bg-primary/5"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                          <method.icon className="w-6 h-6 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm text-secondary">{method.name}</p>
                          <p className="text-xs text-muted-foreground">{method.badge}</p>
                        </div>
                        {selectedPayment === method.id && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="w-6 h-6 bg-primary rounded-full flex items-center justify-center"
                          >
                            <div className="w-2 h-2 bg-secondary rounded-full" />
                          </motion.div>
                        )}
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                onClick={handleSubmit}
                disabled={rating === 0}
                className="w-full h-14 bg-primary hover:bg-accent text-secondary rounded-xl shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-accent/30 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {rating === 0 ? "Please Rate Your Trip" : "Complete & Pay ₹280.00"}
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
