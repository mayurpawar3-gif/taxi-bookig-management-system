import { motion } from "motion/react";
import {
  MapPin,
  Search,
  Star,
  Wallet,
  HelpCircle,
  Clock,
  Navigation,
  Mic,
} from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState } from "react";

const recentTrips = [
  { id: 1, location: "Bandra Kurla Complex (BKC)", address: "Bandra East", time: "2 days ago" },
  { id: 2, location: "Chhatrapati Shivaji Maharaj Terminus", address: "Fort, South Mumbai", time: "1 week ago" },
  { id: 3, location: "Gateway of India", address: "Colaba", time: "2 weeks ago" },
];

const infoDialogs = {
  favorites: {
    title: "Favorites",
    description: "Save your frequently visited locations for quick access. Add home, work, or any place you visit regularly to book rides faster.",
    icon: Star,
    color: "bg-primary"
  },
  wallet: {
    title: "Wallet",
    description: "Manage your RideNow India wallet balance. Add money for cashless payments, view transaction history, and enjoy exclusive offers. Current balance: ₹1,250",
    icon: Wallet,
    color: "bg-success"
  },
  help: {
    title: "Help & Support",
    description: "Need assistance? Access our 24/7 customer support, report issues, view FAQs, or contact us directly. We're here to help make your journey smooth.",
    icon: HelpCircle,
    color: "bg-muted"
  }
};

export function PassengerHome({ onBookRide }: { onBookRide: () => void }) {
  const [showInfoDialog, setShowInfoDialog] = useState<keyof typeof infoDialogs | null>(null);

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Map Section */}
      <div className="flex-1 relative bg-gradient-to-br from-muted/20 to-muted/40">
        {/* Mock Map with animated elements */}
        <div className="absolute inset-0 flex items-center justify-center">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1669508886393-d3ec02f4a330?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwc3RyZWV0JTIwbWFwJTIwbmF2aWdhdGlvbnxlbnwxfHx8fDE3NTk5MDk0MjZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Map"
            className="w-full h-full object-cover opacity-30"
          />
        </div>

        {/* Glowing Location Pin */}
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
        >
          <div className="relative">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center shadow-2xl shadow-primary/40">
              <MapPin className="w-8 h-8 text-secondary" />
            </div>
            <motion.div
              animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 bg-primary rounded-full"
            />
          </div>
        </motion.div>

        {/* Nearby Cars */}
        {[
          { top: "20%", left: "30%" },
          { top: "60%", left: "70%" },
          { top: "40%", left: "20%" },
        ].map((pos, i) => (
          <motion.div
            key={i}
            animate={{ x: [0, 5, 0], y: [0, 3, 0] }}
            transition={{ duration: 3 + i, repeat: Infinity }}
            className="absolute"
            style={{ top: pos.top, left: pos.left }}
          >
            <div className="w-8 h-8 bg-secondary rounded-lg flex items-center justify-center shadow-lg">
              <Navigation className="w-4 h-4 text-primary" />
            </div>
          </motion.div>
        ))}

        {/* Quick Action Buttons */}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          {[
            { icon: Star, label: "Favorites", color: "bg-primary", key: "favorites" as const },
            { icon: Wallet, label: "Wallet", color: "bg-success", key: "wallet" as const },
            { icon: HelpCircle, label: "Help", color: "bg-muted", key: "help" as const },
          ].map((action) => (
            <motion.button
              key={action.label}
              onClick={() => setShowInfoDialog(action.key)}
              whileHover={{ scale: 1.1, x: -5 }}
              whileTap={{ scale: 0.95 }}
              className={`w-12 h-12 ${action.color} rounded-xl flex items-center justify-center shadow-lg hover:shadow-xl transition-all group relative`}
            >
              <action.icon className="w-5 h-5 text-white relative z-10" />
              <motion.div
                className="absolute inset-0 rounded-xl bg-white opacity-0 group-hover:opacity-20 transition-opacity"
              />
            </motion.button>
          ))}
        </div>
      </div>

      {/* Bottom Sheet */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="bg-white rounded-t-3xl shadow-2xl p-6 space-y-4"
      >
        {/* Search Input */}
        <div className="space-y-3">
          <h2 className="text-2xl text-secondary">Where to?</h2>
          
          <motion.div whileHover={{ scale: 1.01 }}>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search destination..."
                className="pl-12 pr-12 h-14 bg-input-background border-2 border-border hover:border-primary focus:border-primary rounded-xl transition-all"
                onClick={onBookRide}
              />
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 w-8 h-8 bg-primary rounded-lg flex items-center justify-center hover:bg-accent transition-colors"
              >
                <Mic className="w-4 h-4 text-secondary" />
              </motion.button>
            </div>
          </motion.div>
        </div>

        {/* Recent Trips */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm text-muted-foreground">Recent Trips</h3>
            <button className="text-xs text-primary hover:text-accent transition-colors">
              View All
            </button>
          </div>

          <div className="space-y-2">
            {recentTrips.map((trip, index) => (
              <motion.div
                key={trip.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ x: 5 }}
              >
                <Card className="p-4 cursor-pointer hover:bg-primary/5 hover:border-primary/20 transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                      <MapPin className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-secondary truncate">{trip.location}</p>
                      <p className="text-xs text-muted-foreground truncate">{trip.address}</p>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {trip.time}
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Book Ride Button */}
        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Button
            onClick={onBookRide}
            className="w-full h-14 bg-primary hover:bg-accent text-secondary rounded-xl shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-accent/30 transition-all duration-300"
          >
            Book a Ride Now
          </Button>
        </motion.div>
      </motion.div>

      {/* Info Dialogs */}
      {showInfoDialog && (
        <Dialog open={!!showInfoDialog} onOpenChange={() => setShowInfoDialog(null)}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                <div className={`w-10 h-10 ${infoDialogs[showInfoDialog].color} rounded-xl flex items-center justify-center`}>
                  {(() => {
                    const IconComponent = infoDialogs[showInfoDialog].icon;
                    return <IconComponent className="w-5 h-5 text-white" />;
                  })()}
                </div>
                {infoDialogs[showInfoDialog].title}
              </DialogTitle>
              <DialogDescription className="pt-4">
                {infoDialogs[showInfoDialog].description}
              </DialogDescription>
            </DialogHeader>
            <div className="pt-4">
              <Button
                onClick={() => setShowInfoDialog(null)}
                className="w-full h-12 bg-primary hover:bg-accent text-secondary rounded-xl"
              >
                Got it!
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
