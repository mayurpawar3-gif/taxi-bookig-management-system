import { motion } from "motion/react";
import { MapPin, DollarSign, Navigation, X, Check, User, Clock } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { useState, useEffect } from "react";

export function DriverRideRequest({
  onAccept,
  onReject,
}: {
  onAccept: () => void;
  onReject: () => void;
}) {
  const [timeLeft, setTimeLeft] = useState(15);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          clearInterval(timer);
          onReject();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [onReject]);

  const progress = ((15 - timeLeft) / 15) * 100;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onReject();
      }}
    >
      <motion.div
        initial={{ scale: 0.8, y: 50 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.8, y: 50 }}
        className="w-full max-w-md"
      >
        <Card className="overflow-hidden shadow-2xl border-2 border-primary/30">
          {/* Header */}
          <div className="p-6 bg-gradient-to-br from-primary to-accent text-secondary">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl">New Ride Request!</h2>
              <motion.button
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={onReject}
                className="w-8 h-8 bg-secondary/20 rounded-lg flex items-center justify-center hover:bg-secondary/30 transition-colors"
              >
                <X className="w-5 h-5" />
              </motion.button>
            </div>

            {/* Timer */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Respond within</span>
                <motion.span
                  animate={{ scale: timeLeft <= 5 ? [1, 1.1, 1] : 1 }}
                  transition={{ duration: 0.5, repeat: timeLeft <= 5 ? Infinity : 0 }}
                  className={timeLeft <= 5 ? "text-destructive" : ""}
                >
                  {timeLeft} seconds
                </motion.span>
              </div>
              <Progress
                value={progress}
                className="h-2 bg-secondary/30"
              />
            </div>
          </div>

          {/* Content */}
          <div className="p-6 space-y-4">
            {/* Passenger Info */}
            <Card className="p-4 bg-primary/5 border-primary/20">
              <div className="flex items-center gap-3 mb-3">
                <Avatar className="w-12 h-12 border-2 border-primary">
                  <AvatarFallback className="bg-primary text-secondary">
                    SP
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="text-base text-secondary">Sarah Passenger</p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">
                      Premium User
                    </Badge>
                    <div className="flex items-center gap-0.5">
                      <span className="text-primary text-sm">★</span>
                      <span className="text-sm">4.8</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Route Details */}
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-success/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-success" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground mb-0.5">Pickup Location</p>
                  <p className="text-sm text-secondary">123 Main Street, Downtown</p>
                  <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                    <Navigation className="w-3 h-3" />
                    <span>1.2 km away</span>
                  </div>
                </div>
              </div>

              <div className="h-8 w-px bg-border ml-5" />

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-destructive/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-destructive" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground mb-0.5">Destination</p>
                  <p className="text-sm text-secondary">456 Airport Road, Terminal 2</p>
                  <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                    <Navigation className="w-3 h-3" />
                    <span>8.5 km trip</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Fare & Time */}
            <Card className="p-4 bg-gradient-to-r from-success/5 to-primary/5">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <DollarSign className="w-5 h-5 text-success" />
                    <p className="text-2xl text-secondary">$26</p>
                  </div>
                  <p className="text-xs text-muted-foreground">Estimated Fare</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Clock className="w-5 h-5 text-primary" />
                    <p className="text-2xl text-secondary">18</p>
                  </div>
                  <p className="text-xs text-muted-foreground">Minutes</p>
                </div>
              </div>
            </Card>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button
                  onClick={onReject}
                  variant="outline"
                  className="w-full h-12 gap-2 border-2 hover:bg-destructive/10 hover:text-destructive hover:border-destructive rounded-xl"
                >
                  <X className="w-5 h-5" />
                  Decline
                </Button>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                animate={{
                  boxShadow: [
                    "0 0 0 0 rgba(255, 180, 0, 0)",
                    "0 0 0 8px rgba(255, 180, 0, 0.1)",
                    "0 0 0 0 rgba(255, 180, 0, 0)",
                  ],
                }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <Button
                  onClick={onAccept}
                  className="w-full h-12 gap-2 bg-primary hover:bg-accent text-secondary rounded-xl shadow-lg shadow-primary/30"
                >
                  <Check className="w-5 h-5" />
                  Accept
                </Button>
              </motion.div>
            </div>
          </div>
        </Card>
      </motion.div>
    </motion.div>
  );
}
