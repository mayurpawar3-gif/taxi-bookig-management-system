import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Bell,
  MessageSquare,
  Settings,
  User,
  Car,
  LogOut,
  CheckCircle,
  AlertCircle,
  Info,
  Clock,
} from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Separator } from "./ui/separator";

interface Notification {
  id: string;
  type: "info" | "success" | "alert";
  message: string;
  time: string;
}

const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "success",
    message: "New ride request accepted",
    time: "2 min ago",
  },
  {
    id: "2",
    type: "info",
    message: "Driver profile updated successfully",
    time: "15 min ago",
  },
  {
    id: "3",
    type: "alert",
    message: "Payment verification required",
    time: "1 hour ago",
  },
];

const mockMessages = [
  {
    id: "1",
    name: "Arjun Sharma",
    message: "On my way to pickup location",
    time: "Just now",
  },
  {
    id: "2",
    name: "Priya Patel",
    message: "Can you wait 2 minutes?",
    time: "5 min ago",
  },
];

interface NotificationBarProps {
  currentView: "passenger" | "driver" | "admin";
  currentScreen?: string;
}

export function NotificationBar({ currentView, currentScreen }: NotificationBarProps) {
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [messagesOpen, setMessagesOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(3);
  const [unreadMessages, setUnreadMessages] = useState(2);

  const notifRef = useRef<HTMLDivElement>(null);
  const messagesRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false);
      }
      if (messagesRef.current && !messagesRef.current.contains(event.target as Node)) {
        setMessagesOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setProfileOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const getPageTitle = () => {
    if (currentView === "admin") return "Admin Dashboard";
    if (currentView === "driver") {
      if (currentScreen === "dashboard") return "Driver Dashboard";
      if (currentScreen === "trip") return "Active Trip";
      return "Driver Portal";
    }
    if (currentView === "passenger") {
      if (currentScreen === "home") return "Book Your Ride";
      if (currentScreen === "tracking") return "Trip in Progress";
      if (currentScreen === "payment") return "Payment & Rating";
      return "RideEasy";
    }
    return "RideEasy";
  };

  const NotificationIcon = ({ type }: { type: "info" | "success" | "alert" }) => {
    const iconProps = { className: "w-4 h-4" };
    switch (type) {
      case "success":
        return <CheckCircle {...iconProps} className="w-4 h-4 text-success" />;
      case "alert":
        return <AlertCircle {...iconProps} className="w-4 h-4 text-destructive" />;
      default:
        return <Info {...iconProps} className="w-4 h-4 text-primary" />;
    }
  };

  return (
    <div className="bg-secondary shadow-[0_2px_8px_rgba(0,0,0,0.2)] border-b border-secondary/20">
      <div className="max-w-7xl mx-auto px-6 py-3">
        <div className="flex items-center justify-between">
          {/* Left: Logo & Brand */}
          <div className="flex items-center gap-3">
            <motion.div
              className="w-11 h-11 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-primary/20"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Car className="w-6 h-6 text-secondary" />
            </motion.div>
            <div>
              <h1 className="text-white text-lg leading-tight">RideNow India Admin</h1>
              <p className="text-xs text-muted leading-tight">Mumbai Management System</p>
            </div>
          </div>

          {/* Center: Page Title */}
          <motion.div
            key={getPageTitle()}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="hidden md:block"
          >
            <h2 className="text-white text-base">{getPageTitle()}</h2>
          </motion.div>

          {/* Right: Interactive Icons */}
          <div className="flex items-center gap-2">
            {/* Notifications */}
            <div className="relative" ref={notifRef}>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  setNotificationsOpen(!notificationsOpen);
                  setMessagesOpen(false);
                  setProfileOpen(false);
                  if (unreadNotifications > 0) setUnreadNotifications(0);
                }}
                className="relative p-2.5 rounded-xl text-white hover:bg-primary/10 hover:text-primary transition-all duration-200 group"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifications > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-1.5 right-1.5 w-2 h-2 bg-destructive rounded-full border-2 border-secondary"
                  />
                )}
                <motion.div
                  className="absolute inset-0 rounded-xl bg-primary opacity-0 group-hover:opacity-10 transition-opacity"
                  style={{ filter: "blur(8px)" }}
                />
              </motion.button>

              <AnimatePresence>
                {notificationsOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-2xl border border-border overflow-hidden z-50"
                  >
                    <div className="p-4 bg-gradient-to-r from-primary/5 to-accent/5 border-b border-border">
                      <h3 className="text-secondary">Notifications</h3>
                      <p className="text-xs text-muted-foreground">You have {mockNotifications.length} notifications</p>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {mockNotifications.map((notif) => (
                        <motion.div
                          key={notif.id}
                          whileHover={{ backgroundColor: "rgba(255, 180, 0, 0.05)" }}
                          className="p-4 border-b border-border last:border-0 cursor-pointer transition-colors"
                        >
                          <div className="flex gap-3">
                            <div className="flex-shrink-0 mt-0.5">
                              <NotificationIcon type={notif.type} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm text-foreground leading-snug">{notif.message}</p>
                              <div className="flex items-center gap-1 mt-1">
                                <Clock className="w-3 h-3 text-muted-foreground" />
                                <p className="text-xs text-muted-foreground">{notif.time}</p>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                    <Button
                      variant="ghost"
                      className="w-full rounded-none h-11 text-primary hover:bg-primary/10 hover:text-primary"
                    >
                      View All Notifications
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Messages */}
            <div className="relative" ref={messagesRef}>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  setMessagesOpen(!messagesOpen);
                  setNotificationsOpen(false);
                  setProfileOpen(false);
                  if (unreadMessages > 0) setUnreadMessages(0);
                }}
                className="relative p-2.5 rounded-xl text-white hover:bg-primary/10 hover:text-primary transition-all duration-200 group"
              >
                <MessageSquare className="w-5 h-5" />
                {unreadMessages > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-1.5 right-1.5 w-2 h-2 bg-destructive rounded-full border-2 border-secondary"
                  />
                )}
                <motion.div
                  className="absolute inset-0 rounded-xl bg-primary opacity-0 group-hover:opacity-10 transition-opacity"
                  style={{ filter: "blur(8px)" }}
                />
              </motion.button>

              <AnimatePresence>
                {messagesOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-2xl border border-border overflow-hidden z-50"
                  >
                    <div className="p-4 bg-gradient-to-r from-primary/5 to-accent/5 border-b border-border">
                      <h3 className="text-secondary">Messages</h3>
                      <p className="text-xs text-muted-foreground">{mockMessages.length} unread messages</p>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {mockMessages.map((msg) => (
                        <motion.div
                          key={msg.id}
                          whileHover={{ backgroundColor: "rgba(255, 180, 0, 0.05)" }}
                          className="p-4 border-b border-border last:border-0 cursor-pointer transition-colors"
                        >
                          <div className="flex gap-3">
                            <Avatar className="w-10 h-10 border-2 border-primary/20">
                              <AvatarFallback className="bg-primary text-secondary">
                                {msg.name[0]}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm text-foreground mb-0.5">{msg.name}</p>
                              <p className="text-sm text-muted-foreground leading-snug truncate">
                                {msg.message}
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">{msg.time}</p>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                    <Button
                      variant="ghost"
                      className="w-full rounded-none h-11 text-primary hover:bg-primary/10 hover:text-primary"
                    >
                      View All Messages
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Settings */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-2.5 rounded-xl text-white hover:bg-primary/10 hover:text-primary transition-all duration-200 group relative"
            >
              <Settings className="w-5 h-5" />
              <motion.div
                className="absolute inset-0 rounded-xl bg-primary opacity-0 group-hover:opacity-10 transition-opacity"
                style={{ filter: "blur(8px)" }}
              />
            </motion.button>

            <Separator orientation="vertical" className="h-8 bg-white/20" />

            {/* Profile */}
            <div className="relative" ref={profileRef}>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  setProfileOpen(!profileOpen);
                  setNotificationsOpen(false);
                  setMessagesOpen(false);
                }}
                className="flex items-center gap-2 p-1.5 pr-3 rounded-xl text-white hover:bg-primary/10 transition-all duration-200 group relative"
              >
                <Avatar className="w-8 h-8 border-2 border-primary">
                  <AvatarFallback className="bg-primary text-secondary">
                    AD
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm hidden lg:block">Admin User</span>
                <motion.div
                  className="absolute inset-0 rounded-xl bg-primary opacity-0 group-hover:opacity-10 transition-opacity"
                  style={{ filter: "blur(8px)" }}
                />
              </motion.button>

              <AnimatePresence>
                {profileOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-2xl border border-border overflow-hidden z-50"
                  >
                    <div className="p-4 bg-gradient-to-r from-primary/5 to-accent/5 border-b border-border">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-12 h-12 border-2 border-primary">
                          <AvatarFallback className="bg-primary text-secondary">
                            AD
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-secondary">Admin User</p>
                          <p className="text-xs text-muted-foreground">admin@rideeasy.com</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-2">
                      <Button
                        variant="ghost"
                        className="w-full justify-start gap-3 hover:bg-primary/10 hover:text-primary"
                      >
                        <User className="w-4 h-4" />
                        Profile Settings
                      </Button>
                      <Button
                        variant="ghost"
                        className="w-full justify-start gap-3 hover:bg-primary/10 hover:text-primary"
                      >
                        <Settings className="w-4 h-4" />
                        Preferences
                      </Button>
                      <Separator className="my-2" />
                      <Button
                        variant="ghost"
                        className="w-full justify-start gap-3 text-destructive hover:bg-destructive/10 hover:text-destructive"
                      >
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
