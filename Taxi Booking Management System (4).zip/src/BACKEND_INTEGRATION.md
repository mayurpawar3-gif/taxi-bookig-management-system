# Backend Integration Guide - RideNow India

This document explains how to integrate the React frontend with a Python Flask backend.

## Flask Backend Structure

### 1. Project Setup

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install flask flask-cors flask-sqlalchemy flask-jwt-extended bcrypt
```

### 2. Backend File Structure

```
backend/
├── app.py              # Main Flask application
├── config.py           # Configuration
├── models.py           # Database models
├── routes/
│   ├── auth.py         # Authentication routes
│   ├── user.py         # User routes
│   ├── driver.py       # Driver routes
│   └── booking.py      # Booking routes
└── requirements.txt    # Python dependencies
```

### 3. Sample Flask Backend (app.py)

```python
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
import bcrypt
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app)

# Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ridenow.db'
app.config['JWT_SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
jwt = JWTManager(app)

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(15), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    wallet_balance = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Driver(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(15), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    vehicle_model = db.Column(db.String(100))
    license_plate = db.Column(db.String(20))
    vehicle_year = db.Column(db.String(4))
    profile_photo = db.Column(db.Text)
    license_photo = db.Column(db.Text)
    is_verified = db.Column(db.Boolean, default=False)
    is_online = db.Column(db.Boolean, default=False)
    rating = db.Column(db.Float, default=5.0)
    total_earnings = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey('driver.id'))
    pickup_location = db.Column(db.String(200), nullable=False)
    drop_location = db.Column(db.String(200), nullable=False)
    vehicle_type = db.Column(db.String(50))
    fare = db.Column(db.Float)
    status = db.Column(db.String(50), default='pending')  # pending, accepted, ongoing, completed, cancelled
    payment_method = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)

# Authentication Routes
@app.route('/api/auth/user/register', methods=['POST'])
def register_user():
    data = request.get_json()
    
    # Validate input
    if not all(key in data for key in ['name', 'email', 'phone', 'password']):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Check if user exists
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Email already registered'}), 400
    
    # Hash password
    password_hash = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt())
    
    # Create user
    user = User(
        name=data['name'],
        email=data['email'],
        phone=data['phone'],
        password_hash=password_hash.decode('utf-8')
    )
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'message': 'User registered successfully'}), 201

@app.route('/api/auth/user/login', methods=['POST'])
def login_user():
    data = request.get_json()
    
    # Find user by email or phone
    user = User.query.filter(
        (User.email == data.get('email')) | (User.phone == data.get('phone'))
    ).first()
    
    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Verify password
    if not bcrypt.checkpw(data['password'].encode('utf-8'), user.password_hash.encode('utf-8')):
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Create access token
    access_token = create_access_token(identity=user.id)
    
    return jsonify({
        'access_token': access_token,
        'user': {
            'id': user.id,
            'name': user.name,
            'email': user.email,
            'phone': user.phone,
            'wallet_balance': user.wallet_balance
        }
    }), 200

@app.route('/api/auth/driver/register', methods=['POST'])
def register_driver():
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['name', 'email', 'phone', 'password', 'vehicle_model', 'license_plate', 'vehicle_year']
    if not all(key in data for key in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Check if driver exists
    if Driver.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Email already registered'}), 400
    
    # Hash password
    password_hash = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt())
    
    # Create driver
    driver = Driver(
        name=data['name'],
        email=data['email'],
        phone=data['phone'],
        password_hash=password_hash.decode('utf-8'),
        vehicle_model=data['vehicle_model'],
        license_plate=data['license_plate'],
        vehicle_year=data['vehicle_year'],
        profile_photo=data.get('profile_photo'),
        license_photo=data.get('license_photo')
    )
    
    db.session.add(driver)
    db.session.commit()
    
    return jsonify({'message': 'Driver registered successfully. Pending verification.'}), 201

@app.route('/api/auth/driver/login', methods=['POST'])
def login_driver():
    data = request.get_json()
    
    # Find driver by email or phone
    driver = Driver.query.filter(
        (Driver.email == data.get('email')) | (Driver.phone == data.get('phone'))
    ).first()
    
    if not driver:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Verify password
    if not bcrypt.checkpw(data['password'].encode('utf-8'), driver.password_hash.encode('utf-8')):
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Create access token
    access_token = create_access_token(identity=driver.id)
    
    return jsonify({
        'access_token': access_token,
        'driver': {
            'id': driver.id,
            'name': driver.name,
            'email': driver.email,
            'phone': driver.phone,
            'vehicle_model': driver.vehicle_model,
            'is_verified': driver.is_verified,
            'rating': driver.rating,
            'total_earnings': driver.total_earnings
        }
    }), 200

# Booking Routes
@app.route('/api/bookings', methods=['POST'])
@jwt_required()
def create_booking():
    user_id = get_jwt_identity()
    data = request.get_json()
    
    # Validate input
    if not all(key in data for key in ['pickup_location', 'drop_location', 'vehicle_type']):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Create booking
    booking = Booking(
        user_id=user_id,
        pickup_location=data['pickup_location'],
        drop_location=data['drop_location'],
        vehicle_type=data['vehicle_type'],
        fare=data.get('fare', 0)
    )
    
    db.session.add(booking)
    db.session.commit()
    
    # Find available driver (simplified - in production, use geolocation)
    available_driver = Driver.query.filter_by(is_online=True, is_verified=True).first()
    
    return jsonify({
        'booking_id': booking.id,
        'status': 'pending',
        'fare': booking.fare,
        'driver': {
            'name': available_driver.name if available_driver else None
        } if available_driver else None
    }), 201

@app.route('/api/bookings/<int:booking_id>/accept', methods=['POST'])
@jwt_required()
def accept_booking(booking_id):
    driver_id = get_jwt_identity()
    
    booking = Booking.query.get(booking_id)
    if not booking:
        return jsonify({'error': 'Booking not found'}), 404
    
    if booking.status != 'pending':
        return jsonify({'error': 'Booking already processed'}), 400
    
    booking.driver_id = driver_id
    booking.status = 'accepted'
    db.session.commit()
    
    return jsonify({'message': 'Booking accepted', 'booking_id': booking.id}), 200

@app.route('/api/bookings/<int:booking_id>/complete', methods=['POST'])
@jwt_required()
def complete_booking(booking_id):
    booking = Booking.query.get(booking_id)
    if not booking:
        return jsonify({'error': 'Booking not found'}), 404
    
    booking.status = 'completed'
    booking.completed_at = datetime.utcnow()
    
    # Update driver earnings
    driver = Driver.query.get(booking.driver_id)
    driver.total_earnings += booking.fare
    
    db.session.commit()
    
    return jsonify({'message': 'Booking completed', 'fare': booking.fare}), 200

# Driver Routes
@app.route('/api/driver/status', methods=['POST'])
@jwt_required()
def update_driver_status():
    driver_id = get_jwt_identity()
    data = request.get_json()
    
    driver = Driver.query.get(driver_id)
    driver.is_online = data.get('is_online', driver.is_online)
    db.session.commit()
    
    return jsonify({'is_online': driver.is_online}), 200

@app.route('/api/driver/earnings', methods=['GET'])
@jwt_required()
def get_driver_earnings():
    driver_id = get_jwt_identity()
    
    # Get today's earnings
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    today_earnings = db.session.query(db.func.sum(Booking.fare)).filter(
        Booking.driver_id == driver_id,
        Booking.status == 'completed',
        Booking.completed_at >= today_start
    ).scalar() or 0
    
    # Get weekly earnings
    week_start = today_start - timedelta(days=today_start.weekday())
    weekly_earnings = db.session.query(db.func.sum(Booking.fare)).filter(
        Booking.driver_id == driver_id,
        Booking.status == 'completed',
        Booking.completed_at >= week_start
    ).scalar() or 0
    
    return jsonify({
        'today': today_earnings,
        'week': weekly_earnings
    }), 200

# Password Reset
@app.route('/api/auth/forgot-password', methods=['POST'])
def forgot_password():
    data = request.get_json()
    
    # In production, send actual email/SMS
    # For now, just return success message
    
    return jsonify({
        'message': 'Password reset link has been sent to your email/phone'
    }), 200

# Initialize database
@app.before_first_request
def create_tables():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, port=5000)
```

### 4. Frontend Integration

Update your React components to call these API endpoints:

```typescript
// utils/api.ts
const API_BASE_URL = 'http://localhost:5000/api';

export const api = {
  // User Authentication
  registerUser: async (userData: any) => {
    const response = await fetch(`${API_BASE_URL}/auth/user/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    return response.json();
  },

  loginUser: async (credentials: any) => {
    const response = await fetch(`${API_BASE_URL}/auth/user/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    return response.json();
  },

  // Driver Authentication
  registerDriver: async (driverData: any) => {
    const response = await fetch(`${API_BASE_URL}/auth/driver/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(driverData)
    });
    return response.json();
  },

  loginDriver: async (credentials: any) => {
    const response = await fetch(`${API_BASE_URL}/auth/driver/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    return response.json();
  },

  // Bookings
  createBooking: async (bookingData: any, token: string) => {
    const response = await fetch(`${API_BASE_URL}/bookings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(bookingData)
    });
    return response.json();
  },

  // Password Reset
  forgotPassword: async (contact: string) => {
    const response = await fetch(`${API_BASE_URL}/auth/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contact })
    });
    return response.json();
  }
};
```

### 5. Database Setup

```bash
# Run Flask app to create database
python app.py
```

### 6. Testing the Integration

```bash
# Test user registration
curl -X POST http://localhost:5000/api/auth/user/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","phone":"+919876543210","password":"test123"}'

# Test user login
curl -X POST http://localhost:5000/api/auth/user/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123"}'
```

### 7. Production Considerations

1. **Security:**
   - Use environment variables for secrets
   - Implement rate limiting
   - Add input sanitization
   - Use HTTPS in production

2. **Database:**
   - Switch from SQLite to PostgreSQL/MySQL for production
   - Implement database migrations (use Flask-Migrate)

3. **Real-time Features:**
   - Add Socket.IO for real-time ride tracking
   - Implement WebSocket connections for live updates

4. **Additional Features:**
   - Add geolocation services (Google Maps API)
   - Implement payment gateway integration
   - Add SMS/Email notification services
   - Implement file upload for images (AWS S3)

5. **Deployment:**
   - Deploy backend on services like Heroku, AWS, or DigitalOcean
   - Deploy frontend on Vercel, Netlify, or AWS S3

## API Endpoints Summary

### Authentication
- `POST /api/auth/user/register` - Register new user
- `POST /api/auth/user/login` - User login
- `POST /api/auth/driver/register` - Register new driver
- `POST /api/auth/driver/login` - Driver login
- `POST /api/auth/forgot-password` - Password reset

### Bookings
- `POST /api/bookings` - Create new booking
- `POST /api/bookings/:id/accept` - Accept booking (driver)
- `POST /api/bookings/:id/complete` - Complete booking

### Driver
- `POST /api/driver/status` - Update online/offline status
- `GET /api/driver/earnings` - Get earnings summary

### Admin (to be implemented)
- `GET /api/admin/users` - Get all users
- `GET /api/admin/drivers` - Get all drivers
- `GET /api/admin/bookings` - Get all bookings
- `GET /api/admin/stats` - Get dashboard statistics

---

**Note:** This backend is a starting point. In production, you'll need to add more features like real-time tracking, payment processing, notifications, and advanced security measures.
