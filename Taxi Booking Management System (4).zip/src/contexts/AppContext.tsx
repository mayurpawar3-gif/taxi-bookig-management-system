import { createContext, useContext, useState, ReactNode } from "react";

// Types
interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  status: "Active" | "Inactive";
  rides: number;
  registeredAt: string;
}

interface Driver {
  id: number;
  name: string;
  email: string;
  phone: string;
  vehicle: string;
  rating: number;
  trips: number;
  status: "Online" | "Offline" | "Busy";
  registeredAt: string;
}

interface RideRequest {
  id: string;
  passengerId: number;
  passengerName: string;
  passengerPhone: string;
  pickup: string;
  dropoff: string;
  distance: string;
  fare: string;
  estimatedTime: string;
  timestamp: string;
  status: "pending" | "accepted" | "rejected" | "completed";
}

interface AppContextType {
  users: User[];
  drivers: Driver[];
  rideRequests: RideRequest[];
  addUser: (user: Omit<User, "id" | "rides" | "status" | "registeredAt">) => void;
  addDriver: (driver: Omit<Driver, "id" | "rating" | "trips" | "status" | "registeredAt">) => void;
  addRideRequest: (request: Omit<RideRequest, "id" | "timestamp" | "status">) => void;
  updateRideRequestStatus: (id: string, status: RideRequest["status"]) => void;
  deleteUser: (id: number) => void;
  deleteDriver: (id: number) => void;
  getNextUserId: () => number;
  getNextDriverId: () => number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Initial data
const initialUsers: User[] = [
  { id: 1, name: "Arjun Sharma", email: "arjun@email.com", phone: "+91 98765 43210", status: "Active", rides: 45, registeredAt: "2025-10-15" },
  { id: 2, name: "Priya Patel", email: "priya@email.com", phone: "+91 98765 43211", status: "Active", rides: 32, registeredAt: "2025-10-18" },
  { id: 3, name: "Rohan Mehta", email: "rohan@email.com", phone: "+91 98765 43212", status: "Inactive", rides: 18, registeredAt: "2025-10-20" },
  { id: 4, name: "Ananya Singh", email: "ananya@email.com", phone: "+91 98765 43213", status: "Active", rides: 67, registeredAt: "2025-10-22" },
  { id: 5, name: "Vikram Desai", email: "vikram@email.com", phone: "+91 98765 43214", status: "Active", rides: 89, registeredAt: "2025-10-25" },
  { id: 6, name: "Kavya Reddy", email: "kavya@email.com", phone: "+91 98765 43215", status: "Active", rides: 23, registeredAt: "2025-10-28" },
  { id: 7, name: "Aditya Jain", email: "aditya@email.com", phone: "+91 98765 43216", status: "Inactive", rides: 12, registeredAt: "2025-10-30" },
];

const initialDrivers: Driver[] = [
  { id: 1, name: "Rajesh Kumar", email: "rajesh@driver.com", phone: "+91 98765 54321", vehicle: "Maruti Ertiga • MH 02 BX 5678", rating: 4.9, trips: 234, status: "Online", registeredAt: "2025-09-10" },
  { id: 2, name: "Amit Verma", email: "amit@driver.com", phone: "+91 98765 54322", vehicle: "Hyundai i20 • MH 01 CK 1234", rating: 4.7, trips: 189, status: "Online", registeredAt: "2025-09-15" },
  { id: 3, name: "Suresh Patil", email: "suresh@driver.com", phone: "+91 98765 54323", vehicle: "Toyota Innova • MH 03 AB 9876", rating: 4.8, trips: 312, status: "Offline", registeredAt: "2025-09-20" },
  { id: 4, name: "Karan Joshi", email: "karan@driver.com", phone: "+91 98765 54324", vehicle: "Honda City • MH 02 XY 4567", rating: 4.6, trips: 156, status: "Busy", registeredAt: "2025-09-25" },
  { id: 5, name: "Rahul Shah", email: "rahul@driver.com", phone: "+91 98765 54325", vehicle: "Maruti Swift • MH 04 ZZ 7890", rating: 4.9, trips: 278, status: "Online", registeredAt: "2025-09-30" },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [drivers, setDrivers] = useState<Driver[]>(initialDrivers);
  const [rideRequests, setRideRequests] = useState<RideRequest[]>([]);

  const getNextUserId = () => {
    return users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
  };

  const getNextDriverId = () => {
    return drivers.length > 0 ? Math.max(...drivers.map(d => d.id)) + 1 : 1;
  };

  const addUser = (userData: Omit<User, "id" | "rides" | "status" | "registeredAt">) => {
    const newUser: User = {
      ...userData,
      id: getNextUserId(),
      rides: 0,
      status: "Active",
      registeredAt: new Date().toISOString().split('T')[0],
    };
    setUsers(prev => [...prev, newUser]);
    console.log("New user added:", newUser);
  };

  const addDriver = (driverData: Omit<Driver, "id" | "rating" | "trips" | "status" | "registeredAt">) => {
    const newDriver: Driver = {
      ...driverData,
      id: getNextDriverId(),
      rating: 5.0,
      trips: 0,
      status: "Offline",
      registeredAt: new Date().toISOString().split('T')[0],
    };
    setDrivers(prev => [...prev, newDriver]);
    console.log("New driver added:", newDriver);
  };

  const addRideRequest = (requestData: Omit<RideRequest, "id" | "timestamp" | "status">) => {
    const newRequest: RideRequest = {
      ...requestData,
      id: `#R${Date.now()}`,
      timestamp: new Date().toLocaleString(),
      status: "pending",
    };
    setRideRequests(prev => [...prev, newRequest]);
    console.log("New ride request created:", newRequest);
  };

  const updateRideRequestStatus = (id: string, status: RideRequest["status"]) => {
    setRideRequests(prev =>
      prev.map(req => req.id === id ? { ...req, status } : req)
    );
  };

  const deleteUser = (id: number) => {
    setUsers(prev => prev.filter(u => u.id !== id));
  };

  const deleteDriver = (id: number) => {
    setDrivers(prev => prev.filter(d => d.id !== id));
  };

  const value: AppContextType = {
    users,
    drivers,
    rideRequests,
    addUser,
    addDriver,
    addRideRequest,
    updateRideRequestStatus,
    deleteUser,
    deleteDriver,
    getNextUserId,
    getNextDriverId,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useAppContext must be used within an AppProvider");
  }
  return context;
}
