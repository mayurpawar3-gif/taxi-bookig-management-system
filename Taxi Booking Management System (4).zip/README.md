
  # Taxi Booking Management System

  This is a code bundle for Taxi Booking Management System. The original project is available at https://www.figma.com/design/SKU6Q46nm3ZSVj8uF4Q2yM/Taxi-Booking-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  